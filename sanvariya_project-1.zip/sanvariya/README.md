# Sanvariya Super Store — ERP

Blue-theme POS & Inventory app with bottom navigation — Login, Dashboard, Products, Billing/POS
(GST + Hold Bill), Purchase, Suppliers, Stock, Reports (sales trend chart). Built with Flutter +
SQLite (offline-first, no internet needed to run) + fl_chart.

## Ismein kya hai (current build)

**Bottom Navigation:** Dashboard · Products · Sale · Reports · More

- **Splash + Login** — username/password (default: `admin` / `admin123`, role: owner)
- **Dashboard** — welcome header, Total Sales / Purchase / Profit / Customers cards,
  8-icon Quick Actions grid, Low Stock Alert list
- **Products** — add/edit/delete, barcode, category, rates, MRP, stock, unit, min stock
- **Billing/POS ("Sale")** — barcode scan/search, cart, Discount + GST%, Hold Bill /
  Held Bills recall, Cash/UPI/Credit, Checkout (auto stock deduct)
- **Purchase** (via More) — select supplier, add products with purchase rate, saves purchase
  and auto-increases stock
- **Suppliers** (via More) — add/edit/delete suppliers
- **Stock** (via More) — current stock, Low Stock / Out of Stock filters, manual adjustment
- **Reports** — Total Sales/Purchase/Bills/Suppliers cards, 7-day Sales Trend line chart,
  Top Selling Products

Database (SQLite) tables: `users`, `products`, `sales` (with gstPercent/gstAmount/status),
`sale_items`, `stock_history`, `suppliers`, `purchases`, `purchase_items`.

Baaki modules (Barcode hardware scanner integration, Thermal Printer, Customer Management,
Sales/Purchase Return, Firebase Cloud Sync, Backup/Restore, Audit Log) is base ke upar
step-by-step add ho sakte hain.

## Apne computer/Codespaces par kaise build karein (APK banane ke liye)

1. **Flutter install karein**: https://docs.flutter.dev/get-started/install (ya GitHub
   Codespaces browser se — pehle jo instructions di thi wahi follow karein)
2. Naya Flutter project banayein:
   ```
   flutter create sanvariya_app
   cd sanvariya_app
   ```
3. Is naye folder ke `lib/` folder aur `pubspec.yaml` file ko **delete** karke, maine diya
   hua `lib/` folder aur `pubspec.yaml` copy-paste kar dein.
4. Dependencies install karein:
   ```
   flutter pub get
   ```
5. APK build karein:
   ```
   flutter build apk --release
   ```
6. APK yahaan milegi:
   ```
   build/app/outputs/flutter-apk/app-release.apk
   ```

Test karne ke liye (bina APK banaye, seedhe phone/emulator par):
```
flutter run
```

## Default Login
- Username: `admin`
- Password: `admin123`
