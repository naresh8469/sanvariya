import 'package:flutter/material.dart';
import '../database/database_helper.dart';
import '../models/product.dart';
import '../models/supplier.dart';
import '../models/purchase.dart';
import '../theme/app_theme.dart';

class PurchaseScreen extends StatefulWidget {
  const PurchaseScreen({super.key});

  @override
  State<PurchaseScreen> createState() => _PurchaseScreenState();
}

class _PurchaseScreenState extends State<PurchaseScreen> {
  List<Supplier> _suppliers = [];
  Supplier? _selectedSupplier;
  final List<PurchaseCartItem> _cart = [];
  final _searchController = TextEditingController();
  List<Product> _searchResults = [];
  String _paymentMode = 'Cash';

  double get _total => _cart.fold(0, (sum, item) => sum + item.total);

  @override
  void initState() {
    super.initState();
    _loadSuppliers();
  }

  Future<void> _loadSuppliers() async {
    final list = await DatabaseHelper.instance.getAllSuppliers();
    setState(() {
      _suppliers = list;
      if (list.isNotEmpty) _selectedSupplier = list.first;
    });
  }

  Future<void> _search(String query) async {
    if (query.isEmpty) {
      setState(() => _searchResults = []);
      return;
    }
    final results = await DatabaseHelper.instance.searchProducts(query);
    setState(() => _searchResults = results);
  }

  void _addToCart(Product p) {
    setState(() {
      final existing = _cart.indexWhere((c) => c.productId == p.id);
      if (existing >= 0) {
        _cart[existing].quantity += 1;
      } else {
        _cart.add(PurchaseCartItem(productId: p.id!, productName: p.name, rate: p.purchaseRate));
      }
      _searchController.clear();
      _searchResults = [];
    });
  }

  Future<void> _savePurchase() async {
    if (_selectedSupplier == null) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Pehle supplier select karein')));
      return;
    }
    if (_cart.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Cart khali hai')));
      return;
    }

    final purchaseNo = 'PUR${DateTime.now().millisecondsSinceEpoch}';
    final purchase = Purchase(
      purchaseNo: purchaseNo,
      supplierId: _selectedSupplier!.id!,
      supplierName: _selectedSupplier!.name,
      totalAmount: _total,
      paymentMode: _paymentMode,
      dateTime: DateTime.now().toIso8601String(),
    );

    await DatabaseHelper.instance.savePurchase(purchase, _cart);

    if (!mounted) return;
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('Purchase Saved'),
        content: Text('Purchase No: $purchaseNo\nTotal: ₹${_total.toStringAsFixed(2)}\nStock updated.'),
        actions: [
          TextButton(
            onPressed: () {
              Navigator.pop(context);
              Navigator.pop(context);
            },
            child: const Text('OK'),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('New Purchase')),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(12),
            child: Column(
              children: [
                DropdownButtonFormField<Supplier>(
                  value: _selectedSupplier,
                  decoration: const InputDecoration(labelText: 'Supplier'),
                  items: _suppliers.map((s) => DropdownMenuItem(value: s, child: Text(s.name))).toList(),
                  onChanged: (v) => setState(() => _selectedSupplier = v),
                ),
                if (_suppliers.isEmpty)
                  const Padding(
                    padding: EdgeInsets.only(top: 6),
                    child: Text('Koi supplier nahi hai — pehle More > Suppliers se add karein', style: TextStyle(color: Colors.red, fontSize: 12)),
                  ),
                const SizedBox(height: 10),
                TextField(
                  controller: _searchController,
                  decoration: const InputDecoration(hintText: 'Product search karein', prefixIcon: Icon(Icons.search)),
                  onChanged: _search,
                ),
              ],
            ),
          ),
          if (_searchResults.isNotEmpty)
            SizedBox(
              height: 150,
              child: ListView.builder(
                itemCount: _searchResults.length,
                itemBuilder: (context, i) {
                  final p = _searchResults[i];
                  return ListTile(
                    title: Text(p.name),
                    subtitle: Text('Purchase Rate: ₹${p.purchaseRate}  •  Stock: ${p.quantity}'),
                    onTap: () => _addToCart(p),
                  );
                },
              ),
            ),
          const Divider(height: 1),
          Expanded(
            child: _cart.isEmpty
                ? const Center(child: Text('Cart khali hai'))
                : ListView.builder(
                    itemCount: _cart.length,
                    itemBuilder: (context, index) {
                      final item = _cart[index];
                      return ListTile(
                        title: Text(item.productName),
                        subtitle: Row(
                          children: [
                            const Text('Qty: '),
                            SizedBox(
                              width: 50,
                              child: TextFormField(
                                initialValue: item.quantity.toString(),
                                keyboardType: TextInputType.number,
                                decoration: const InputDecoration(isDense: true),
                                onChanged: (v) => setState(() => item.quantity = double.tryParse(v) ?? item.quantity),
                              ),
                            ),
                            const SizedBox(width: 12),
                            const Text('Rate: ₹'),
                            SizedBox(
                              width: 60,
                              child: TextFormField(
                                initialValue: item.rate.toString(),
                                keyboardType: TextInputType.number,
                                decoration: const InputDecoration(isDense: true),
                                onChanged: (v) => setState(() => item.rate = double.tryParse(v) ?? item.rate),
                              ),
                            ),
                          ],
                        ),
                        trailing: Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Text('₹${item.total.toStringAsFixed(0)}'),
                            IconButton(
                              icon: const Icon(Icons.delete_outline, color: Colors.red),
                              onPressed: () => setState(() => _cart.removeAt(index)),
                            ),
                          ],
                        ),
                      );
                    },
                  ),
          ),
          Container(
            padding: const EdgeInsets.all(16),
            decoration: const BoxDecoration(color: Colors.white, border: Border(top: BorderSide(color: AppTheme.cardBorder))),
            child: Column(
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    const Text('Payment Mode'),
                    DropdownButton<String>(
                      value: _paymentMode,
                      items: ['Cash', 'UPI', 'Credit'].map((m) => DropdownMenuItem(value: m, child: Text(m))).toList(),
                      onChanged: (v) => setState(() => _paymentMode = v!),
                    ),
                  ],
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    const Text('Total', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                    Text('₹${_total.toStringAsFixed(2)}', style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
                  ],
                ),
                const SizedBox(height: 10),
                SizedBox(
                  width: double.infinity,
                  height: 48,
                  child: ElevatedButton(onPressed: _savePurchase, child: const Text('Save Purchase')),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
