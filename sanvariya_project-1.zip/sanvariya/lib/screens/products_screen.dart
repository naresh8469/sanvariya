import 'package:flutter/material.dart';
import '../database/database_helper.dart';
import '../models/product.dart';

class ProductsScreen extends StatefulWidget {
  final bool embedded;
  const ProductsScreen({super.key, this.embedded = false});

  @override
  State<ProductsScreen> createState() => _ProductsScreenState();
}

class _ProductsScreenState extends State<ProductsScreen> {
  List<Product> _products = [];
  bool _loading = true;
  final _searchController = TextEditingController();

  @override
  void initState() {
    super.initState();
    _loadProducts();
  }

  Future<void> _loadProducts() async {
    setState(() => _loading = true);
    final list = _searchController.text.isEmpty
        ? await DatabaseHelper.instance.getAllProducts()
        : await DatabaseHelper.instance.searchProducts(_searchController.text);
    setState(() {
      _products = list;
      _loading = false;
    });
  }

  Future<void> _deleteProduct(Product p) async {
    final confirm = await showDialog<bool>(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('Delete Product'),
        content: Text('"${p.name}" ko delete karein?'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Cancel')),
          TextButton(onPressed: () => Navigator.pop(context, true), child: const Text('Delete')),
        ],
      ),
    );
    if (confirm == true) {
      await DatabaseHelper.instance.deleteProduct(p.id!);
      _loadProducts();
    }
  }

  void _openProductForm({Product? product}) async {
    final saved = await showModalBottomSheet<bool>(
      context: context,
      isScrollControlled: true,
      builder: (_) => _ProductForm(product: product),
    );
    if (saved == true) _loadProducts();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Products'),
      ),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(12),
            child: TextField(
              controller: _searchController,
              decoration: InputDecoration(
                hintText: 'Search by name or barcode',
                prefixIcon: const Icon(Icons.search),
                border: OutlineInputBorder(borderRadius: BorderRadius.circular(8)),
              ),
              onChanged: (_) => _loadProducts(),
            ),
          ),
          Expanded(
            child: _loading
                ? const Center(child: CircularProgressIndicator())
                : _products.isEmpty
                    ? const Center(child: Text('Koi product nahi mila'))
                    : ListView.builder(
                        itemCount: _products.length,
                        itemBuilder: (context, index) {
                          final p = _products[index];
                          final lowStock = p.quantity <= p.minStock;
                          return Card(
                            margin: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
                            child: ListTile(
                              title: Text(p.name),
                              subtitle: Text(
                                'Barcode: ${p.barcode}  •  Stock: ${p.quantity} ${p.unit}\nRate: ₹${p.sellingRate}  MRP: ₹${p.mrp}',
                              ),
                              isThreeLine: true,
                              leading: CircleAvatar(
                                backgroundColor: lowStock ? Colors.red[100] : Colors.green[100],
                                child: Icon(
                                  lowStock ? Icons.warning_amber : Icons.check,
                                  color: lowStock ? Colors.red : Colors.green,
                                ),
                              ),
                              trailing: PopupMenuButton<String>(
                                onSelected: (v) {
                                  if (v == 'edit') _openProductForm(product: p);
                                  if (v == 'delete') _deleteProduct(p);
                                },
                                itemBuilder: (_) => [
                                  const PopupMenuItem(value: 'edit', child: Text('Edit')),
                                  const PopupMenuItem(value: 'delete', child: Text('Delete')),
                                ],
                              ),
                            ),
                          );
                        },
                      ),
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () => _openProductForm(),
        child: const Icon(Icons.add),
      ),
    );
  }
}

class _ProductForm extends StatefulWidget {
  final Product? product;
  const _ProductForm({this.product});

  @override
  State<_ProductForm> createState() => _ProductFormState();
}

class _ProductFormState extends State<_ProductForm> {
  final _formKey = GlobalKey<FormState>();
  late TextEditingController _name, _barcode, _category, _purchaseRate,
      _sellingRate, _mrp, _quantity, _unit, _minStock;

  @override
  void initState() {
    super.initState();
    final p = widget.product;
    _name = TextEditingController(text: p?.name ?? '');
    _barcode = TextEditingController(text: p?.barcode ?? '');
    _category = TextEditingController(text: p?.category ?? '');
    _purchaseRate = TextEditingController(text: p?.purchaseRate.toString() ?? '');
    _sellingRate = TextEditingController(text: p?.sellingRate.toString() ?? '');
    _mrp = TextEditingController(text: p?.mrp.toString() ?? '');
    _quantity = TextEditingController(text: p?.quantity.toString() ?? '');
    _unit = TextEditingController(text: p?.unit ?? 'pcs');
    _minStock = TextEditingController(text: p?.minStock.toString() ?? '5');
  }

  Future<void> _save() async {
    if (!_formKey.currentState!.validate()) return;

    final product = Product(
      id: widget.product?.id,
      name: _name.text.trim(),
      barcode: _barcode.text.trim(),
      category: _category.text.trim(),
      purchaseRate: double.tryParse(_purchaseRate.text) ?? 0,
      sellingRate: double.tryParse(_sellingRate.text) ?? 0,
      mrp: double.tryParse(_mrp.text) ?? 0,
      quantity: double.tryParse(_quantity.text) ?? 0,
      unit: _unit.text.trim().isEmpty ? 'pcs' : _unit.text.trim(),
      minStock: double.tryParse(_minStock.text) ?? 0,
    );

    if (widget.product == null) {
      await DatabaseHelper.instance.addProduct(product);
    } else {
      await DatabaseHelper.instance.updateProduct(product);
    }

    if (mounted) Navigator.pop(context, true);
  }

  Widget _field(String label, TextEditingController c, {bool number = false, bool required = true}) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: TextFormField(
        controller: c,
        keyboardType: number ? const TextInputType.numberWithOptions(decimal: true) : TextInputType.text,
        decoration: InputDecoration(labelText: label, border: const OutlineInputBorder()),
        validator: required ? (v) => (v == null || v.trim().isEmpty) ? '$label required' : null : null,
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsets.only(
        left: 16, right: 16, top: 16,
        bottom: MediaQuery.of(context).viewInsets.bottom + 16,
      ),
      child: SingleChildScrollView(
        child: Form(
          key: _formKey,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Text(
                widget.product == null ? 'Add Product' : 'Edit Product',
                style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
              ),
              const SizedBox(height: 16),
              _field('Product Name', _name),
              _field('Barcode', _barcode, required: false),
              _field('Category', _category, required: false),
              Row(
                children: [
                  Expanded(child: _field('Purchase Rate', _purchaseRate, number: true)),
                  const SizedBox(width: 8),
                  Expanded(child: _field('Selling Rate', _sellingRate, number: true)),
                ],
              ),
              Row(
                children: [
                  Expanded(child: _field('MRP', _mrp, number: true)),
                  const SizedBox(width: 8),
                  Expanded(child: _field('Quantity', _quantity, number: true)),
                ],
              ),
              Row(
                children: [
                  Expanded(child: _field('Unit (pcs/kg/ltr)', _unit)),
                  const SizedBox(width: 8),
                  Expanded(child: _field('Minimum Stock', _minStock, number: true)),
                ],
              ),
              const SizedBox(height: 8),
              ElevatedButton(
                onPressed: _save,
                child: const Text('Save'),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
