import 'package:flutter/material.dart';
import '../database/database_helper.dart';
import '../models/product.dart';
import '../models/sale.dart';
import '../theme/app_theme.dart';

class BillingScreen extends StatefulWidget {
  final bool embedded;
  const BillingScreen({super.key, this.embedded = false});

  @override
  State<BillingScreen> createState() => _BillingScreenState();
}

class _BillingScreenState extends State<BillingScreen> {
  final List<CartItem> _cart = [];
  final _searchController = TextEditingController();
  final _customerController = TextEditingController();
  List<Product> _searchResults = [];
  double _discount = 0;
  double _gstPercent = 5;
  String _paymentMode = 'Cash';

  double get _subtotal => _cart.fold(0, (sum, item) => sum + item.total);
  double get _gstAmount => (_subtotal - _discount).clamp(0, double.infinity) * _gstPercent / 100;
  double get _grandTotal => (_subtotal - _discount).clamp(0, double.infinity) + _gstAmount;

  Future<void> _search(String query) async {
    if (query.isEmpty) {
      setState(() => _searchResults = []);
      return;
    }
    final results = await DatabaseHelper.instance.searchProducts(query);
    setState(() => _searchResults = results);
  }

  void _addToCart(Product p) {
    setState(() {
      final existing = _cart.indexWhere((c) => c.product.id == p.id);
      if (existing >= 0) {
        _cart[existing].quantity += 1;
      } else {
        _cart.add(CartItem(product: p));
      }
      _searchController.clear();
      _searchResults = [];
    });
  }

  void _updateQty(int index, double qty) {
    if (qty <= 0) {
      setState(() => _cart.removeAt(index));
    } else {
      setState(() => _cart[index].quantity = qty);
    }
  }

  void _clearCart() {
    setState(() {
      _cart.clear();
      _discount = 0;
      _customerController.clear();
    });
  }

  Sale _buildSale(String billNo) {
    return Sale(
      billNo: billNo,
      customerName: _customerController.text.trim().isEmpty ? 'Walk-in' : _customerController.text.trim(),
      subtotal: _subtotal,
      discount: _discount,
      gstPercent: _gstPercent,
      gstAmount: _gstAmount,
      totalAmount: _grandTotal,
      paymentMode: _paymentMode,
      dateTime: DateTime.now().toIso8601String(),
    );
  }

  Future<void> _holdBill() async {
    if (_cart.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Cart khali hai')));
      return;
    }
    final billNo = 'HOLD${DateTime.now().millisecondsSinceEpoch}';
    await DatabaseHelper.instance.saveSale(_buildSale(billNo), _cart, status: 'held');
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Bill hold kar diya gaya')));
    _clearCart();
  }

  Future<void> _checkout() async {
    if (_cart.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Cart khali hai')));
      return;
    }

    final billNo = 'BILL${DateTime.now().millisecondsSinceEpoch}';
    final sale = _buildSale(billNo);
    await DatabaseHelper.instance.saveSale(sale, _cart, status: 'completed');

    if (!mounted) return;
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('Bill Saved'),
        content: Text(
          'Bill No: $billNo\nSubtotal: ₹${_subtotal.toStringAsFixed(2)}\nDiscount: ₹${_discount.toStringAsFixed(2)}\nGST (${_gstPercent.toStringAsFixed(0)}%): ₹${_gstAmount.toStringAsFixed(2)}\nTotal: ₹${_grandTotal.toStringAsFixed(2)}\nPayment: $_paymentMode',
        ),
        actions: [
          TextButton(
            onPressed: () {
              Navigator.pop(context);
              _clearCart();
              if (!widget.embedded) Navigator.pop(context);
            },
            child: const Text('OK'),
          ),
        ],
      ),
    );
  }

  Future<void> _showHeldBills() async {
    final held = await DatabaseHelper.instance.getHeldBills();
    if (!mounted) return;
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      builder: (context) => DraggableScrollableSheet(
        initialChildSize: 0.5,
        maxChildSize: 0.9,
        expand: false,
        builder: (context, scrollController) => Padding(
          padding: const EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text('Held Bills', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
              const SizedBox(height: 10),
              Expanded(
                child: held.isEmpty
                    ? const Center(child: Text('Koi held bill nahi hai'))
                    : ListView.builder(
                        controller: scrollController,
                        itemCount: held.length,
                        itemBuilder: (context, i) {
                          final s = held[i];
                          return Card(
                            child: ListTile(
                              title: Text('${s.customerName} • ₹${s.totalAmount.toStringAsFixed(2)}'),
                              subtitle: Text(s.billNo),
                              trailing: IconButton(
                                icon: const Icon(Icons.delete_outline, color: Colors.red),
                                onPressed: () async {
                                  await DatabaseHelper.instance.deleteHeldBill(s.id!);
                                  if (context.mounted) Navigator.pop(context);
                                },
                              ),
                              onTap: () async {
                                final items = await DatabaseHelper.instance.getSaleItems(s.id!);
                                final products = await DatabaseHelper.instance.getAllProducts();
                                setState(() {
                                  _cart.clear();
                                  for (final item in items) {
                                    final product = products.firstWhere(
                                      (p) => p.id == item.productId,
                                      orElse: () => Product(
                                        id: item.productId,
                                        name: item.productName,
                                        barcode: '',
                                        category: '',
                                        purchaseRate: 0,
                                        sellingRate: item.rate,
                                        mrp: 0,
                                        quantity: 0,
                                        unit: 'pcs',
                                        minStock: 0,
                                      ),
                                    );
                                    _cart.add(CartItem(product: product, quantity: item.quantity));
                                  }
                                  _customerController.text = s.customerName;
                                  _discount = s.discount;
                                  _gstPercent = s.gstPercent;
                                });
                                await DatabaseHelper.instance.deleteHeldBill(s.id!);
                                if (context.mounted) Navigator.pop(context);
                              },
                            ),
                          );
                        },
                      ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final body = Column(
      children: [
        Padding(
          padding: const EdgeInsets.all(12),
          child: Column(
            children: [
              TextField(
                controller: _customerController,
                decoration: const InputDecoration(hintText: 'Customer Name (optional)', prefixIcon: Icon(Icons.person_outline)),
              ),
              const SizedBox(height: 8),
              TextField(
                controller: _searchController,
                decoration: const InputDecoration(hintText: 'Search product by name or scan barcode', prefixIcon: Icon(Icons.qr_code_scanner)),
                onChanged: _search,
                onSubmitted: (value) async {
                  final p = await DatabaseHelper.instance.getProductByBarcode(value.trim());
                  if (p != null) _addToCart(p);
                },
              ),
            ],
          ),
        ),
        if (_searchResults.isNotEmpty)
          SizedBox(
            height: 160,
            child: ListView.builder(
              itemCount: _searchResults.length,
              itemBuilder: (context, i) {
                final p = _searchResults[i];
                return ListTile(
                  leading: const CircleAvatar(backgroundColor: AppTheme.bg, child: Icon(Icons.inventory_2_outlined, size: 18)),
                  title: Text(p.name),
                  subtitle: Text('₹${p.sellingRate} • Stock: ${p.quantity}'),
                  trailing: const Icon(Icons.add_circle, color: AppTheme.primaryBlue),
                  onTap: () => _addToCart(p),
                );
              },
            ),
          ),
        const Divider(height: 1),
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text('Cart (${_cart.length} Items)', style: const TextStyle(fontWeight: FontWeight.bold)),
              TextButton(onPressed: _clearCart, child: const Text('Clear', style: TextStyle(color: Colors.red))),
            ],
          ),
        ),
        Expanded(
          child: _cart.isEmpty
              ? const Center(child: Text('Cart khali hai — product search karein'))
              : ListView.builder(
                  itemCount: _cart.length,
                  itemBuilder: (context, index) {
                    final item = _cart[index];
                    return ListTile(
                      leading: const CircleAvatar(backgroundColor: AppTheme.bg, child: Icon(Icons.inventory_2_outlined, size: 18)),
                      title: Text(item.product.name),
                      subtitle: Text('₹${item.product.sellingRate} x ${item.quantity} = ₹${item.total.toStringAsFixed(2)}'),
                      trailing: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          IconButton(icon: const Icon(Icons.remove_circle_outline), onPressed: () => _updateQty(index, item.quantity - 1)),
                          Text('${item.quantity}'),
                          IconButton(icon: const Icon(Icons.add_circle_outline), onPressed: () => _updateQty(index, item.quantity + 1)),
                        ],
                      ),
                    );
                  },
                ),
        ),
        Container(
          padding: const EdgeInsets.all(16),
          decoration: const BoxDecoration(color: Colors.white, border: Border(top: BorderSide(color: AppTheme.cardBorder))),
          child: Column(
            children: [
              Row(
                children: [
                  const Text('Discount ₹'),
                  const SizedBox(width: 8),
                  Expanded(
                    child: TextField(
                      keyboardType: TextInputType.number,
                      decoration: const InputDecoration(isDense: true),
                      onChanged: (v) => setState(() => _discount = double.tryParse(v) ?? 0),
                    ),
                  ),
                  const SizedBox(width: 8),
                  const Text('GST %'),
                  const SizedBox(width: 8),
                  SizedBox(
                    width: 70,
                    child: TextField(
                      keyboardType: TextInputType.number,
                      controller: TextEditingController(text: _gstPercent.toStringAsFixed(0)),
                      decoration: const InputDecoration(isDense: true),
                      onChanged: (v) => setState(() => _gstPercent = double.tryParse(v) ?? 0),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 8),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  const Text('Subtotal'),
                  Text('₹${_subtotal.toStringAsFixed(2)}'),
                ],
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text('Tax (GST ${_gstPercent.toStringAsFixed(0)}%)'),
                  Text('₹${_gstAmount.toStringAsFixed(2)}'),
                ],
              ),
              const SizedBox(height: 6),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  const Text('Total Amount', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
                  Text('₹${_grandTotal.toStringAsFixed(2)}', style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: AppTheme.primaryBlue)),
                ],
              ),
              const SizedBox(height: 12),
              Row(
                children: [
                  Expanded(
                    child: OutlinedButton(onPressed: _holdBill, child: const Text('Hold')),
                  ),
                  const SizedBox(width: 8),
                  Expanded(
                    child: OutlinedButton(
                      onPressed: _showHeldBills,
                      child: const Text('Held Bills'),
                    ),
                  ),
                  const SizedBox(width: 8),
                  Expanded(
                    child: ElevatedButton(
                      style: ElevatedButton.styleFrom(backgroundColor: AppTheme.accentGreen),
                      onPressed: _checkout,
                      child: const Text('Checkout'),
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ],
    );

    return Scaffold(
      appBar: AppBar(
        title: Text(widget.embedded ? 'New Sale (Bill)' : 'New Bill'),
      ),
      body: body,
    );
  }
}
