import 'package:sqflite/sqflite.dart';
import 'package:path/path.dart';
import '../models/product.dart';
import '../models/user.dart';
import '../models/sale.dart';
import '../models/supplier.dart';
import '../models/purchase.dart';

class DatabaseHelper {
  DatabaseHelper._privateConstructor();
  static final DatabaseHelper instance = DatabaseHelper._privateConstructor();

  static Database? _database;

  Future<Database> get database async {
    if (_database != null) return _database!;
    _database = await _initDatabase();
    return _database!;
  }

  Future<Database> _initDatabase() async {
    final dbPath = await getDatabasesPath();
    final path = join(dbPath, 'sanvariya.db');
    return await openDatabase(
      path,
      version: 2,
      onCreate: _onCreate,
    );
  }

  Future<void> _onCreate(Database db, int version) async {
    await db.execute('''
      CREATE TABLE users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        username TEXT UNIQUE NOT NULL,
        password TEXT NOT NULL,
        role TEXT NOT NULL
      )
    ''');

    await db.execute('''
      CREATE TABLE products (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        barcode TEXT,
        category TEXT,
        purchaseRate REAL NOT NULL DEFAULT 0,
        sellingRate REAL NOT NULL DEFAULT 0,
        mrp REAL NOT NULL DEFAULT 0,
        quantity REAL NOT NULL DEFAULT 0,
        unit TEXT NOT NULL DEFAULT 'pcs',
        minStock REAL NOT NULL DEFAULT 0
      )
    ''');

    await db.execute('''
      CREATE TABLE sales (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        billNo TEXT NOT NULL,
        customerName TEXT,
        subtotal REAL NOT NULL DEFAULT 0,
        discount REAL NOT NULL DEFAULT 0,
        gstPercent REAL NOT NULL DEFAULT 0,
        gstAmount REAL NOT NULL DEFAULT 0,
        totalAmount REAL NOT NULL,
        paymentMode TEXT NOT NULL,
        status TEXT NOT NULL DEFAULT 'completed',
        dateTime TEXT NOT NULL
      )
    ''');

    await db.execute('''
      CREATE TABLE sale_items (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        saleId INTEGER NOT NULL,
        productId INTEGER NOT NULL,
        productName TEXT NOT NULL,
        quantity REAL NOT NULL,
        rate REAL NOT NULL,
        total REAL NOT NULL,
        FOREIGN KEY (saleId) REFERENCES sales (id),
        FOREIGN KEY (productId) REFERENCES products (id)
      )
    ''');

    await db.execute('''
      CREATE TABLE stock_history (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        productId INTEGER NOT NULL,
        changeType TEXT NOT NULL,
        changeQty REAL NOT NULL,
        note TEXT,
        dateTime TEXT NOT NULL
      )
    ''');

    await db.execute('''
      CREATE TABLE suppliers (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        contact TEXT,
        address TEXT
      )
    ''');

    await db.execute('''
      CREATE TABLE purchases (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        purchaseNo TEXT NOT NULL,
        supplierId INTEGER NOT NULL,
        supplierName TEXT NOT NULL,
        totalAmount REAL NOT NULL,
        paymentMode TEXT NOT NULL,
        dateTime TEXT NOT NULL,
        FOREIGN KEY (supplierId) REFERENCES suppliers (id)
      )
    ''');

    await db.execute('''
      CREATE TABLE purchase_items (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        purchaseId INTEGER NOT NULL,
        productId INTEGER NOT NULL,
        productName TEXT NOT NULL,
        quantity REAL NOT NULL,
        rate REAL NOT NULL,
        total REAL NOT NULL,
        FOREIGN KEY (purchaseId) REFERENCES purchases (id),
        FOREIGN KEY (productId) REFERENCES products (id)
      )
    ''');

    await db.insert('users', {
      'username': 'admin',
      'password': 'admin123',
      'role': 'owner',
    });
  }

  // ---------------- USERS / LOGIN ----------------

  Future<AppUser?> login(String username, String password) async {
    final db = await database;
    final result = await db.query(
      'users',
      where: 'username = ? AND password = ?',
      whereArgs: [username, password],
    );
    if (result.isNotEmpty) return AppUser.fromMap(result.first);
    return null;
  }

  Future<int> addUser(AppUser user) async {
    final db = await database;
    return await db.insert('users', user.toMap());
  }

  // ---------------- PRODUCTS ----------------

  Future<int> addProduct(Product product) async {
    final db = await database;
    return await db.insert('products', product.toMap()..remove('id'));
  }

  Future<int> updateProduct(Product product) async {
    final db = await database;
    return await db.update('products', product.toMap(), where: 'id = ?', whereArgs: [product.id]);
  }

  Future<int> deleteProduct(int id) async {
    final db = await database;
    return await db.delete('products', where: 'id = ?', whereArgs: [id]);
  }

  Future<List<Product>> getAllProducts() async {
    final db = await database;
    final result = await db.query('products', orderBy: 'name ASC');
    return result.map((e) => Product.fromMap(e)).toList();
  }

  Future<List<Product>> searchProducts(String query) async {
    final db = await database;
    final result = await db.query(
      'products',
      where: 'name LIKE ? OR barcode LIKE ?',
      whereArgs: ['%$query%', '%$query%'],
    );
    return result.map((e) => Product.fromMap(e)).toList();
  }

  Future<Product?> getProductByBarcode(String barcode) async {
    final db = await database;
    final result = await db.query('products', where: 'barcode = ?', whereArgs: [barcode]);
    if (result.isNotEmpty) return Product.fromMap(result.first);
    return null;
  }

  Future<List<Product>> getLowStockProducts() async {
    final db = await database;
    final result = await db.rawQuery('SELECT * FROM products WHERE quantity <= minStock');
    return result.map((e) => Product.fromMap(e)).toList();
  }

  // ---------------- STOCK ----------------

  Future<void> adjustStock(int productId, double changeQty, String changeType, {String? note}) async {
    final db = await database;
    await db.rawUpdate('UPDATE products SET quantity = quantity + ? WHERE id = ?', [changeQty, productId]);
    await db.insert('stock_history', {
      'productId': productId,
      'changeType': changeType,
      'changeQty': changeQty,
      'note': note ?? '',
      'dateTime': DateTime.now().toIso8601String(),
    });
  }

  // ---------------- SALES / BILLING ----------------

  /// Saves a bill. status = 'completed' deducts stock immediately.
  /// status = 'held' just parks the bill without touching stock.
  Future<int> saveSale(Sale sale, List<CartItem> items, {String status = 'completed'}) async {
    final db = await database;
    late int saleId;

    await db.transaction((txn) async {
      final map = sale.toMap()..remove('id');
      map['status'] = status;
      saleId = await txn.insert('sales', map);

      for (final item in items) {
        await txn.insert('sale_items', {
          'saleId': saleId,
          'productId': item.product.id,
          'productName': item.product.name,
          'quantity': item.quantity,
          'rate': item.product.sellingRate,
          'total': item.total,
        });

        if (status == 'completed') {
          await txn.rawUpdate(
            'UPDATE products SET quantity = quantity - ? WHERE id = ?',
            [item.quantity, item.product.id],
          );
          await txn.insert('stock_history', {
            'productId': item.product.id,
            'changeType': 'SALE',
            'changeQty': -item.quantity,
            'note': 'Bill #${sale.billNo}',
            'dateTime': DateTime.now().toIso8601String(),
          });
        }
      }
    });

    return saleId;
  }

  Future<List<Sale>> getAllSales({String status = 'completed'}) async {
    final db = await database;
    final result = await db.query('sales', where: 'status = ?', whereArgs: [status], orderBy: 'dateTime DESC');
    return result.map((e) => Sale.fromMap(e)).toList();
  }

  Future<List<Sale>> getHeldBills() async => getAllSales(status: 'held');

  Future<List<SaleItem>> getSaleItems(int saleId) async {
    final db = await database;
    final result = await db.query('sale_items', where: 'saleId = ?', whereArgs: [saleId]);
    return result.map((e) => SaleItem.fromMap(e)).toList();
  }

  Future<void> deleteHeldBill(int saleId) async {
    final db = await database;
    await db.delete('sale_items', where: 'saleId = ?', whereArgs: [saleId]);
    await db.delete('sales', where: 'id = ?', whereArgs: [saleId]);
  }

  Future<List<Sale>> getTodaySales() async {
    final db = await database;
    final today = DateTime.now();
    final start = DateTime(today.year, today.month, today.day).toIso8601String();
    final result = await db.query(
      'sales',
      where: 'dateTime >= ? AND status = ?',
      whereArgs: [start, 'completed'],
      orderBy: 'dateTime DESC',
    );
    return result.map((e) => Sale.fromMap(e)).toList();
  }

  Future<double> getTodaySalesTotal() async {
    final sales = await getTodaySales();
    double total = 0;
    for (final s in sales) {
      total += s.totalAmount;
    }
    return total;
  }

  Future<int> getTotalCustomers() async {
    final db = await database;
    final result = await db.rawQuery(
      "SELECT COUNT(DISTINCT customerName) as cnt FROM sales WHERE status = 'completed' AND customerName != 'Walk-in'",
    );
    return Sqflite.firstIntValue(result) ?? 0;
  }

  /// Sales total per day for the last [days] days (for the trend chart).
  Future<List<MapEntry<DateTime, double>>> getSalesTrend({int days = 7}) async {
    final db = await database;
    final result = <MapEntry<DateTime, double>>[];
    final now = DateTime.now();

    for (int i = days - 1; i >= 0; i--) {
      final day = DateTime(now.year, now.month, now.day).subtract(Duration(days: i));
      final nextDay = day.add(const Duration(days: 1));
      final rows = await db.rawQuery(
        "SELECT COALESCE(SUM(totalAmount), 0) as total FROM sales WHERE status = 'completed' AND dateTime >= ? AND dateTime < ?",
        [day.toIso8601String(), nextDay.toIso8601String()],
      );
      final total = (rows.first['total'] as num).toDouble();
      result.add(MapEntry(day, total));
    }
    return result;
  }

  Future<List<MapEntry<String, double>>> getTopSellingProducts({int limit = 5}) async {
    final db = await database;
    final result = await db.rawQuery('''
      SELECT productName, SUM(quantity) as qty
      FROM sale_items
      GROUP BY productName
      ORDER BY qty DESC
      LIMIT ?
    ''', [limit]);
    return result.map((e) => MapEntry(e['productName'] as String, (e['qty'] as num).toDouble())).toList();
  }

  // ---------------- SUPPLIERS ----------------

  Future<int> addSupplier(Supplier s) async {
    final db = await database;
    return await db.insert('suppliers', s.toMap()..remove('id'));
  }

  Future<int> updateSupplier(Supplier s) async {
    final db = await database;
    return await db.update('suppliers', s.toMap(), where: 'id = ?', whereArgs: [s.id]);
  }

  Future<int> deleteSupplier(int id) async {
    final db = await database;
    return await db.delete('suppliers', where: 'id = ?', whereArgs: [id]);
  }

  Future<List<Supplier>> getAllSuppliers() async {
    final db = await database;
    final result = await db.query('suppliers', orderBy: 'name ASC');
    return result.map((e) => Supplier.fromMap(e)).toList();
  }

  // ---------------- PURCHASE ----------------

  Future<int> savePurchase(Purchase purchase, List<PurchaseCartItem> items) async {
    final db = await database;
    late int purchaseId;

    await db.transaction((txn) async {
      purchaseId = await txn.insert('purchases', purchase.toMap()..remove('id'));

      for (final item in items) {
        await txn.insert('purchase_items', {
          'purchaseId': purchaseId,
          'productId': item.productId,
          'productName': item.productName,
          'quantity': item.quantity,
          'rate': item.rate,
          'total': item.total,
        });

        await txn.rawUpdate(
          'UPDATE products SET quantity = quantity + ? WHERE id = ?',
          [item.quantity, item.productId],
        );

        await txn.insert('stock_history', {
          'productId': item.productId,
          'changeType': 'PURCHASE',
          'changeQty': item.quantity,
          'note': 'Purchase #${purchase.purchaseNo}',
          'dateTime': DateTime.now().toIso8601String(),
        });
      }
    });

    return purchaseId;
  }

  Future<List<Purchase>> getAllPurchases() async {
    final db = await database;
    final result = await db.query('purchases', orderBy: 'dateTime DESC');
    return result.map((e) => Purchase.fromMap(e)).toList();
  }

  Future<double> getTodayPurchaseTotal() async {
    final db = await database;
    final today = DateTime.now();
    final start = DateTime(today.year, today.month, today.day).toIso8601String();
    final result = await db.rawQuery(
      'SELECT COALESCE(SUM(totalAmount), 0) as total FROM purchases WHERE dateTime >= ?',
      [start],
    );
    return (result.first['total'] as num).toDouble();
  }

  Future<double> getTotalPurchaseAmount() async {
    final db = await database;
    final result = await db.rawQuery('SELECT COALESCE(SUM(totalAmount), 0) as total FROM purchases');
    return (result.first['total'] as num).toDouble();
  }

  Future<double> getTotalSalesAmount() async {
    final db = await database;
    final result = await db.rawQuery(
      "SELECT COALESCE(SUM(totalAmount), 0) as total FROM sales WHERE status = 'completed'",
    );
    return (result.first['total'] as num).toDouble();
  }

  Future<int> getTotalBillCount() async {
    final db = await database;
    final result = await db.rawQuery("SELECT COUNT(*) as cnt FROM sales WHERE status = 'completed'");
    return Sqflite.firstIntValue(result) ?? 0;
  }
}
