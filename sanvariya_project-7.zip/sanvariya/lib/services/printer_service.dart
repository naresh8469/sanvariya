import 'package:blue_thermal_printer/blue_thermal_printer.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../models/sale.dart';

/// Wraps a classic-Bluetooth ESC/POS thermal printer (the common cheap
/// 2"/3" receipt printers used in Indian shops). Handles pairing selection,
/// remembering the chosen printer, and printing a formatted bill.
class PrinterService {
  static final BlueThermalPrinter _printer = BlueThermalPrinter.instance;

  static Future<List<BluetoothDevice>> getBondedDevices() async {
    try {
      return await _printer.getBondedDevices();
    } catch (_) {
      return [];
    }
  }

  static Future<bool> get isConnected async {
    try {
      return await _printer.isConnected ?? false;
    } catch (_) {
      return false;
    }
  }

  static Future<void> saveDefaultPrinter(BluetoothDevice device) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('printer_name', device.name ?? 'Printer');
    await prefs.setString('printer_address', device.address ?? '');
  }

  static Future<String?> getSavedPrinterName() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getString('printer_name');
  }

  static Future<bool> connect(BluetoothDevice device) async {
    try {
      await _printer.connect(device);
      return true;
    } catch (_) {
      return false;
    }
  }

  /// Connects to the previously saved printer (if it's currently paired).
  /// Returns true if a connection was made.
  static Future<bool> connectToSaved() async {
    final prefs = await SharedPreferences.getInstance();
    final address = prefs.getString('printer_address');
    if (address == null) return false;

    final devices = await getBondedDevices();
    BluetoothDevice? match;
    for (final d in devices) {
      if (d.address == address) {
        match = d;
        break;
      }
    }
    if (match == null) return false;
    return connect(match);
  }

  static Future<void> disconnect() async {
    try {
      await _printer.disconnect();
    } catch (_) {}
  }

  static String _line([String char = '-']) => char * 32;

  static String _twoCol(String left, String right) {
    const width = 32;
    final space = width - left.length - right.length;
    if (space <= 0) {
      // left too long, truncate
      final l = left.substring(0, (width - right.length - 1).clamp(0, left.length));
      return '$l ${' ' * (width - l.length - right.length - 1)}$right';
    }
    return '$left${' ' * space}$right';
  }

  /// Prints a bill receipt. Assumes a connection is already established
  /// (call [connectToSaved] or [connect] first).
  static Future<bool> printReceipt({
    required String storeName,
    required Sale sale,
    required List<SaleItem> items,
  }) async {
    try {
      final connected = await isConnected;
      if (!connected) return false;

      _printer.printCustom(storeName, 3, 1); // size 3 (large), align 1 (center)
      _printer.printCustom('Super Store', 1, 1);
      _printer.printNewLine();
      _printer.printCustom(_line(), 1, 0);
      _printer.printLeftRight('Bill No:', sale.billNo, 1);
      _printer.printLeftRight('Date:', sale.dateTime.substring(0, 16).replaceAll('T', ' '), 1);
      _printer.printLeftRight('Customer:', sale.customerName, 1);
      _printer.printCustom(_line(), 1, 0);

      for (final item in items) {
        _printer.printCustom(item.productName, 1, 0);
        _printer.printCustom(
          _twoCol('${item.quantity.toStringAsFixed(0)} x ${item.rate.toStringAsFixed(2)}', item.total.toStringAsFixed(2)),
          1,
          0,
        );
      }

      _printer.printCustom(_line(), 1, 0);
      _printer.printLeftRight('Subtotal:', sale.subtotal.toStringAsFixed(2), 1);
      if (sale.discount > 0) _printer.printLeftRight('Discount:', '-${sale.discount.toStringAsFixed(2)}', 1);
      if (sale.gstAmount > 0) _printer.printLeftRight('GST (${sale.gstPercent.toStringAsFixed(0)}%):', sale.gstAmount.toStringAsFixed(2), 1);
      _printer.printCustom(_line(), 1, 0);
      _printer.printLeftRight('TOTAL:', 'Rs ${sale.totalAmount.toStringAsFixed(2)}', 2);
      _printer.printLeftRight('Payment:', sale.paymentMode, 1);
      _printer.printNewLine();
      _printer.printCustom('Thank You! Visit Again', 1, 1);
      _printer.printNewLine();
      _printer.printNewLine();
      _printer.paperCut();
      return true;
    } catch (_) {
      return false;
    }
  }
}
