import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../theme/app_theme.dart';
import 'purchase_screen.dart';
import 'suppliers_screen.dart';
import 'stock_screen.dart';
import 'bill_scan_screen.dart';
import 'settings_screen.dart';
import 'printer_settings_screen.dart';
import 'backup_screen.dart';
import 'login_screen.dart';

class MoreScreen extends StatelessWidget {
  final String username;
  final String role;

  const MoreScreen({super.key, required this.username, required this.role});

  Future<void> _logout(BuildContext context) async {
    final confirm = await showDialog<bool>(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('Logout'),
        content: const Text('Kya aap logout karna chahte hain?'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Cancel')),
          TextButton(onPressed: () => Navigator.pop(context, true), child: const Text('Logout')),
        ],
      ),
    );
    if (confirm != true) return;

    final prefs = await SharedPreferences.getInstance();
    await prefs.clear();
    if (!context.mounted) return;
    Navigator.pushAndRemoveUntil(
      context,
      MaterialPageRoute(builder: (_) => const LoginScreen()),
      (route) => false,
    );
  }

  Widget _menuTile(BuildContext context, IconData icon, Color color, String title, String subtitle, VoidCallback onTap) {
    return Card(
      margin: const EdgeInsets.only(bottom: 10),
      child: ListTile(
        leading: CircleAvatar(backgroundColor: color.withValues(alpha: 0.12), child: Icon(icon, color: color)),
        title: Text(title, style: const TextStyle(fontWeight: FontWeight.w600)),
        subtitle: Text(subtitle, style: const TextStyle(fontSize: 12)),
        trailing: const Icon(Icons.chevron_right),
        onTap: onTap,
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('More')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Card(
            color: AppTheme.primaryBlue,
            margin: const EdgeInsets.only(bottom: 16),
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Row(
                children: [
                  CircleAvatar(radius: 24, backgroundColor: Colors.white, child: Icon(Icons.person, color: AppTheme.primaryBlue)),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(username, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 16)),
                        Text(role[0].toUpperCase() + role.substring(1), style: const TextStyle(color: Colors.white70, fontSize: 12)),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),
          _menuTile(context, Icons.local_shipping_outlined, AppTheme.accentTeal, 'Purchase', 'New purchase entry, history',
              () => Navigator.push(context, MaterialPageRoute(builder: (_) => const PurchaseScreen()))),
          _menuTile(context, Icons.receipt_long, AppTheme.accentGreen, 'Bill Photo Entry', 'Supplier bill ki photo se stock update',
              () => Navigator.push(context, MaterialPageRoute(builder: (_) => const BillScanScreen()))),
          _menuTile(context, Icons.groups_outlined, AppTheme.accentPurple, 'Suppliers', 'Add/edit suppliers, outstanding',
              () => Navigator.push(context, MaterialPageRoute(builder: (_) => const SuppliersScreen()))),
          _menuTile(context, Icons.warehouse_outlined, AppTheme.accentOrange, 'Stock / Inventory', 'Current stock, adjustments',
              () => Navigator.push(context, MaterialPageRoute(builder: (_) => const StockScreen()))),
          _menuTile(context, Icons.palette_outlined, AppTheme.accentTeal, 'Settings', 'Theme: Day / Night / Hacker',
              () => Navigator.push(context, MaterialPageRoute(builder: (_) => const SettingsScreen()))),
          _menuTile(context, Icons.print_outlined, AppTheme.primaryBlue, 'Printer Settings', 'Bluetooth thermal printer connect karein',
              () => Navigator.push(context, MaterialPageRoute(builder: (_) => const PrinterSettingsScreen()))),
          _menuTile(context, Icons.backup_outlined, AppTheme.accentGreen, 'Backup / Restore', 'Apna data surakshit rakhein',
              () => Navigator.push(context, MaterialPageRoute(builder: (_) => const BackupScreen()))),
          _menuTile(context, Icons.logout, AppTheme.accentRed, 'Logout', 'Sign out of this account',
              () => _logout(context)),
        ],
      ),
    );
  }
}
