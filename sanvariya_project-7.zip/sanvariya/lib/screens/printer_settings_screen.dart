import 'package:flutter/material.dart';
import 'package:blue_thermal_printer/blue_thermal_printer.dart';
import '../services/printer_service.dart';
import '../theme/app_theme.dart';

class PrinterSettingsScreen extends StatefulWidget {
  const PrinterSettingsScreen({super.key});

  @override
  State<PrinterSettingsScreen> createState() => _PrinterSettingsScreenState();
}

class _PrinterSettingsScreenState extends State<PrinterSettingsScreen> {
  List<BluetoothDevice> _devices = [];
  String? _savedName;
  bool _loading = true;
  bool _connecting = false;
  String? _connectingAddress;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() => _loading = true);
    final devices = await PrinterService.getBondedDevices();
    final saved = await PrinterService.getSavedPrinterName();
    setState(() {
      _devices = devices;
      _savedName = saved;
      _loading = false;
    });
  }

  Future<void> _connectAndSave(BluetoothDevice device) async {
    setState(() {
      _connecting = true;
      _connectingAddress = device.address;
    });
    final ok = await PrinterService.connect(device);
    if (ok) {
      await PrinterService.saveDefaultPrinter(device);
    }
    setState(() {
      _connecting = false;
      _connectingAddress = null;
      if (ok) _savedName = device.name ?? 'Printer';
    });
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(ok ? '${device.name} connect ho gaya aur default set ho gaya' : 'Connect nahi ho paya, dobara try karein')),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Printer Settings'),
        actions: [IconButton(icon: const Icon(Icons.refresh), onPressed: _load)],
      ),
      body: Column(
        children: [
          Container(
            width: double.infinity,
            padding: const EdgeInsets.all(16),
            color: AppTheme.primaryBlue.withValues(alpha: 0.08),
            child: Row(
              children: [
                Icon(Icons.print, color: AppTheme.primaryBlue),
                const SizedBox(width: 10),
                Expanded(
                  child: Text(
                    _savedName != null ? 'Default Printer: $_savedName' : 'Koi printer set nahi hai',
                    style: const TextStyle(fontWeight: FontWeight.bold),
                  ),
                ),
              ],
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(12),
            child: Text(
              'Pehle apne printer ko phone ki Bluetooth settings mein "Pair" kar lein, phir yahan uski list mein dikhega.',
              style: TextStyle(fontSize: 12, color: Colors.grey.shade600),
            ),
          ),
          Expanded(
            child: _loading
                ? const Center(child: CircularProgressIndicator())
                : _devices.isEmpty
                    ? const Center(child: Text('Koi paired Bluetooth device nahi mila'))
                    : ListView.builder(
                        padding: const EdgeInsets.symmetric(horizontal: 12),
                        itemCount: _devices.length,
                        itemBuilder: (context, i) {
                          final d = _devices[i];
                          final isSaved = d.name == _savedName;
                          final isBusy = _connecting && _connectingAddress == d.address;
                          return Card(
                            margin: const EdgeInsets.only(bottom: 8),
                            child: ListTile(
                              leading: Icon(Icons.print, color: isSaved ? AppTheme.accentGreen : Colors.grey),
                              title: Text(d.name ?? 'Unknown'),
                              subtitle: Text(d.address ?? ''),
                              trailing: isBusy
                                  ? const SizedBox(width: 20, height: 20, child: CircularProgressIndicator(strokeWidth: 2))
                                  : isSaved
                                      ? Icon(Icons.check_circle, color: AppTheme.accentGreen)
                                      : const Icon(Icons.chevron_right),
                              onTap: isBusy ? null : () => _connectAndSave(d),
                            ),
                          );
                        },
                      ),
          ),
        ],
      ),
    );
  }
}
