import 'product.dart';

class Sale {
  final int? id;
  final String billNo;
  final String customerName;
  final double subtotal;
  final double discount;
  final double gstPercent;
  final double gstAmount;
  final double totalAmount;
  final String paymentMode; // Cash, UPI, Credit
  final String status; // completed, held
  final String dateTime;

  Sale({
    this.id,
    required this.billNo,
    required this.customerName,
    required this.subtotal,
    required this.discount,
    required this.gstPercent,
    required this.gstAmount,
    required this.totalAmount,
    required this.paymentMode,
    this.status = 'completed',
    required this.dateTime,
  });

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'billNo': billNo,
      'customerName': customerName,
      'subtotal': subtotal,
      'discount': discount,
      'gstPercent': gstPercent,
      'gstAmount': gstAmount,
      'totalAmount': totalAmount,
      'paymentMode': paymentMode,
      'status': status,
      'dateTime': dateTime,
    };
  }

  factory Sale.fromMap(Map<String, dynamic> map) {
    return Sale(
      id: map['id'] as int?,
      billNo: map['billNo'] as String,
      customerName: map['customerName'] as String,
      subtotal: (map['subtotal'] as num?)?.toDouble() ?? 0,
      discount: (map['discount'] as num).toDouble(),
      gstPercent: (map['gstPercent'] as num?)?.toDouble() ?? 0,
      gstAmount: (map['gstAmount'] as num?)?.toDouble() ?? 0,
      totalAmount: (map['totalAmount'] as num).toDouble(),
      paymentMode: map['paymentMode'] as String,
      status: map['status'] as String? ?? 'completed',
      dateTime: map['dateTime'] as String,
    );
  }
}

class SaleItem {
  final int? id;
  final int saleId;
  final int productId;
  final String productName;
  final double quantity;
  final double rate;
  final double total;

  SaleItem({
    this.id,
    required this.saleId,
    required this.productId,
    required this.productName,
    required this.quantity,
    required this.rate,
    required this.total,
  });

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'saleId': saleId,
      'productId': productId,
      'productName': productName,
      'quantity': quantity,
      'rate': rate,
      'total': total,
    };
  }

  factory SaleItem.fromMap(Map<String, dynamic> map) {
    return SaleItem(
      id: map['id'] as int?,
      saleId: map['saleId'] as int,
      productId: map['productId'] as int,
      productName: map['productName'] as String,
      quantity: (map['quantity'] as num).toDouble(),
      rate: (map['rate'] as num).toDouble(),
      total: (map['total'] as num).toDouble(),
    );
  }
}

/// Represents one line in the cart before the bill is saved.
class CartItem {
  final Product product;
  double quantity;

  CartItem({required this.product, this.quantity = 1});

  double get total => product.sellingRate * quantity;
}
