class Product {
  final int? id;
  final String name;
  final String barcode;
  final String category;
  final double purchaseRate;
  final double sellingRate;
  final double mrp;
  final double quantity;
  final String unit;
  final double minStock;

  Product({
    this.id,
    required this.name,
    required this.barcode,
    required this.category,
    required this.purchaseRate,
    required this.sellingRate,
    required this.mrp,
    required this.quantity,
    required this.unit,
    required this.minStock,
  });

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'name': name,
      'barcode': barcode,
      'category': category,
      'purchaseRate': purchaseRate,
      'sellingRate': sellingRate,
      'mrp': mrp,
      'quantity': quantity,
      'unit': unit,
      'minStock': minStock,
    };
  }

  factory Product.fromMap(Map<String, dynamic> map) {
    return Product(
      id: map['id'] as int?,
      name: map['name'] as String,
      barcode: map['barcode'] as String,
      category: map['category'] as String,
      purchaseRate: (map['purchaseRate'] as num).toDouble(),
      sellingRate: (map['sellingRate'] as num).toDouble(),
      mrp: (map['mrp'] as num).toDouble(),
      quantity: (map['quantity'] as num).toDouble(),
      unit: map['unit'] as String,
      minStock: (map['minStock'] as num).toDouble(),
    );
  }

  Product copyWith({
    int? id,
    String? name,
    String? barcode,
    String? category,
    double? purchaseRate,
    double? sellingRate,
    double? mrp,
    double? quantity,
    String? unit,
    double? minStock,
  }) {
    return Product(
      id: id ?? this.id,
      name: name ?? this.name,
      barcode: barcode ?? this.barcode,
      category: category ?? this.category,
      purchaseRate: purchaseRate ?? this.purchaseRate,
      sellingRate: sellingRate ?? this.sellingRate,
      mrp: mrp ?? this.mrp,
      quantity: quantity ?? this.quantity,
      unit: unit ?? this.unit,
      minStock: minStock ?? this.minStock,
    );
  }
}
