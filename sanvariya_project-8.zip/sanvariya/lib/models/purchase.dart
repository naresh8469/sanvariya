class Purchase {
  final int? id;
  final String purchaseNo;
  final int supplierId;
  final String supplierName;
  final double totalAmount;
  final String paymentMode; // Cash, UPI, Credit
  final String dateTime;

  Purchase({
    this.id,
    required this.purchaseNo,
    required this.supplierId,
    required this.supplierName,
    required this.totalAmount,
    required this.paymentMode,
    required this.dateTime,
  });

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'purchaseNo': purchaseNo,
      'supplierId': supplierId,
      'supplierName': supplierName,
      'totalAmount': totalAmount,
      'paymentMode': paymentMode,
      'dateTime': dateTime,
    };
  }

  factory Purchase.fromMap(Map<String, dynamic> map) {
    return Purchase(
      id: map['id'] as int?,
      purchaseNo: map['purchaseNo'] as String,
      supplierId: map['supplierId'] as int,
      supplierName: map['supplierName'] as String,
      totalAmount: (map['totalAmount'] as num).toDouble(),
      paymentMode: map['paymentMode'] as String,
      dateTime: map['dateTime'] as String,
    );
  }
}

class PurchaseCartItem {
  final int productId;
  final String productName;
  double quantity;
  double rate;

  PurchaseCartItem({
    required this.productId,
    required this.productName,
    this.quantity = 1,
    this.rate = 0,
  });

  double get total => quantity * rate;
}
