class Supplier {
  final int? id;
  final String name;
  final String contact;
  final String address;

  Supplier({
    this.id,
    required this.name,
    required this.contact,
    required this.address,
  });

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'name': name,
      'contact': contact,
      'address': address,
    };
  }

  factory Supplier.fromMap(Map<String, dynamic> map) {
    return Supplier(
      id: map['id'] as int?,
      name: map['name'] as String,
      contact: map['contact'] as String,
      address: map['address'] as String,
    );
  }
}
