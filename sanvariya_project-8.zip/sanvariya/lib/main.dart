import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'screens/splash_screen.dart';
import 'theme/app_theme.dart';
import 'theme/theme_controller.dart';

void main() {
  runApp(
    ChangeNotifierProvider(
      create: (_) => ThemeController(),
      child: const SanvariyaApp(),
    ),
  );
}

class SanvariyaApp extends StatelessWidget {
  const SanvariyaApp({super.key});

  @override
  Widget build(BuildContext context) {
    final themeType = context.watch<ThemeController>().themeType;
    return MaterialApp(
      title: 'Sanvariya Super Store',
      debugShowCheckedModeBanner: false,
      theme: AppTheme.themeFor(themeType),
      home: const SplashScreen(),
    );
  }
}
