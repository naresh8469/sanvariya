import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'app_theme.dart';

class ThemeController extends ChangeNotifier {
  AppThemeType _themeType = AppThemeType.day;
  AppThemeType get themeType => _themeType;

  ThemeController() {
    _load();
  }

  Future<void> _load() async {
    final prefs = await SharedPreferences.getInstance();
    final saved = prefs.getString('app_theme_type');
    if (saved != null) {
      _themeType = AppThemeType.values.firstWhere(
        (e) => e.name == saved,
        orElse: () => AppThemeType.day,
      );
      notifyListeners();
    }
  }

  Future<void> setTheme(AppThemeType type) async {
    _themeType = type;
    notifyListeners();
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('app_theme_type', type.name);
  }
}
