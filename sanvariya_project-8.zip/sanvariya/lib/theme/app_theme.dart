import 'package:flutter/material.dart';

enum AppThemeType { day, night, hacker }

class AppTheme {
  /// The currently active theme — set by [themeFor] each time the app
  /// rebuilds with a new theme. Screens read AppTheme.primaryBlue etc as
  /// plain static getters, so this must be kept in sync before the widget
  /// tree below MaterialApp builds.
  static AppThemeType currentTheme = AppThemeType.day;

  static Color get primaryBlue {
    switch (currentTheme) {
      case AppThemeType.day:
        return const Color(0xFF0D47A1);
      case AppThemeType.night:
        return const Color(0xFF4A90D9);
      case AppThemeType.hacker:
        return const Color(0xFF00FF41);
    }
  }

  static Color get primaryBlueDark {
    switch (currentTheme) {
      case AppThemeType.day:
        return const Color(0xFF0A3A85);
      case AppThemeType.night:
        return const Color(0xFF2E5FA3);
      case AppThemeType.hacker:
        return const Color(0xFF00CC33);
    }
  }

  static Color get accentGreen {
    switch (currentTheme) {
      case AppThemeType.day:
        return const Color(0xFF2E7D32);
      case AppThemeType.night:
        return const Color(0xFF4CAF50);
      case AppThemeType.hacker:
        return const Color(0xFF00FF41);
    }
  }

  static Color get accentOrange {
    switch (currentTheme) {
      case AppThemeType.day:
        return const Color(0xFFEF6C00);
      case AppThemeType.night:
        return const Color(0xFFFFA726);
      case AppThemeType.hacker:
        return const Color(0xFF33FF66);
    }
  }

  static Color get accentPurple {
    switch (currentTheme) {
      case AppThemeType.day:
        return const Color(0xFF6A1B9A);
      case AppThemeType.night:
        return const Color(0xFFAB47BC);
      case AppThemeType.hacker:
        return const Color(0xFF00994D);
    }
  }

  static Color get accentTeal {
    switch (currentTheme) {
      case AppThemeType.day:
        return const Color(0xFF00838F);
      case AppThemeType.night:
        return const Color(0xFF26C6DA);
      case AppThemeType.hacker:
        return const Color(0xFF00E676);
    }
  }

  // Danger/warning stays red in every theme so alerts remain unmistakable.
  static Color get accentRed {
    switch (currentTheme) {
      case AppThemeType.day:
        return const Color(0xFFC62828);
      case AppThemeType.night:
        return const Color(0xFFEF5350);
      case AppThemeType.hacker:
        return const Color(0xFFFF3333);
    }
  }

  static Color get bg {
    switch (currentTheme) {
      case AppThemeType.day:
        return const Color(0xFFF3F5F9);
      case AppThemeType.night:
        return const Color(0xFF121212);
      case AppThemeType.hacker:
        return Colors.black;
    }
  }

  static Color get cardBg {
    switch (currentTheme) {
      case AppThemeType.day:
        return Colors.white;
      case AppThemeType.night:
        return const Color(0xFF1E1E1E);
      case AppThemeType.hacker:
        return const Color(0xFF0A0A0A);
    }
  }

  static Color get cardBorder {
    switch (currentTheme) {
      case AppThemeType.day:
        return const Color(0xFFE3E7EF);
      case AppThemeType.night:
        return const Color(0xFF2E2E2E);
      case AppThemeType.hacker:
        return const Color(0xFF00701F);
    }
  }

  static Color get textColor {
    switch (currentTheme) {
      case AppThemeType.day:
        return const Color(0xFF1C2A22);
      case AppThemeType.night:
        return Colors.white;
      case AppThemeType.hacker:
        return const Color(0xFF00FF41);
    }
  }

  static String get themeName {
    switch (currentTheme) {
      case AppThemeType.day:
        return 'Day';
      case AppThemeType.night:
        return 'Night';
      case AppThemeType.hacker:
        return 'Hacker';
    }
  }

  /// Builds the ThemeData for [type] and — as a side effect — sets
  /// [currentTheme], so every screen's static AppTheme.* color getters
  /// resolve correctly the next time they build.
  static ThemeData themeFor(AppThemeType type) {
    currentTheme = type;
    final isDark = type != AppThemeType.day;
    final isHacker = type == AppThemeType.hacker;

    return ThemeData(
      useMaterial3: true,
      brightness: isDark ? Brightness.dark : Brightness.light,
      scaffoldBackgroundColor: bg,
      fontFamily: isHacker ? 'monospace' : null,
      colorScheme: ColorScheme.fromSeed(
        seedColor: primaryBlue,
        brightness: isDark ? Brightness.dark : Brightness.light,
        primary: primaryBlue,
      ),
      appBarTheme: AppBarTheme(
        backgroundColor: isHacker ? Colors.black : primaryBlue,
        foregroundColor: isHacker ? primaryBlue : Colors.white,
        elevation: 0,
        centerTitle: false,
        titleTextStyle: TextStyle(
          color: isHacker ? primaryBlue : Colors.white,
          fontSize: 20,
          fontWeight: FontWeight.w600,
          fontFamily: isHacker ? 'monospace' : null,
        ),
        iconTheme: IconThemeData(color: isHacker ? primaryBlue : Colors.white),
      ),
      elevatedButtonTheme: ElevatedButtonThemeData(
        style: ElevatedButton.styleFrom(
          backgroundColor: primaryBlue,
          foregroundColor: isHacker ? Colors.black : Colors.white,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
        ),
      ),
      outlinedButtonTheme: OutlinedButtonThemeData(
        style: OutlinedButton.styleFrom(
          foregroundColor: primaryBlue,
          side: BorderSide(color: primaryBlue),
        ),
      ),
      cardTheme: CardThemeData(
        elevation: 0,
        color: cardBg,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(12),
          side: BorderSide(color: cardBorder),
        ),
      ),
      dividerColor: cardBorder,
      textTheme: (isDark ? Typography.material2021().white : Typography.material2021().black).apply(
        bodyColor: textColor,
        displayColor: textColor,
        fontFamily: isHacker ? 'monospace' : null,
      ),
      inputDecorationTheme: InputDecorationTheme(
        filled: true,
        fillColor: cardBg,
        border: OutlineInputBorder(borderRadius: BorderRadius.circular(8), borderSide: BorderSide(color: cardBorder)),
        enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(8), borderSide: BorderSide(color: cardBorder)),
        labelStyle: TextStyle(color: textColor.withValues(alpha: 0.7)),
      ),
      navigationBarTheme: NavigationBarThemeData(
        backgroundColor: cardBg,
        indicatorColor: primaryBlue.withValues(alpha: isHacker ? 0.25 : 0.12),
      ),
    );
  }
}
