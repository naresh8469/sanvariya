/// One editable row on the Bill Scan review screen — a best-effort guess
/// parsed from a single OCR text line of a supplier invoice. The user
/// reviews and corrects these before confirming.
class BillRow {
  String productName;
  double quantity;
  bool isBox;
  double piecesPerBox;
  double purchaseRate;
  double mrp;
  bool include;

  BillRow({
    required this.productName,
    this.quantity = 1,
    this.isBox = false,
    this.piecesPerBox = 1,
    this.purchaseRate = 0,
    this.mrp = 0,
    this.include = true,
  });

  double get totalPieces => isBox ? quantity * piecesPerBox : quantity;
}

class BillLineParser {
  static final _numberPattern = RegExp(r'\d+(\.\d+)?');
  static final _boxKeywords = RegExp(r'\b(box|boxes|ctn|carton|case|pkt)\b', caseSensitive: false);
  static final _perBoxPattern = RegExp(r'[x×]\s*(\d+)|(\d+)\s*(pcs|pc|piece|nos)\b', caseSensitive: false);

  /// Parses raw OCR lines into best-guess rows. Skips lines that look like
  /// headers, totals, or dates rather than product rows.
  static List<BillRow> parse(List<String> lines) {
    final rows = <BillRow>[];

    for (final raw in lines) {
      final line = raw.trim();
      if (line.length < 3) continue;

      final lower = line.toLowerCase();
      // Skip obvious non-product lines.
      if (lower.contains(RegExp(r'\btotal\b|\bgst\b|\binvoice\b|\bbill no\b|\bdate\b|\bsubtotal\b|'
          r'\baddress\b|\bphone\b|\bgstin\b|\bsignature\b|\bthank you\b'))) {
        continue;
      }

      final numbers = _numberPattern.allMatches(line).map((m) => double.tryParse(m.group(0)!) ?? 0).toList();
      final isBox = _boxKeywords.hasMatch(line);

      double qty = 1, rate = 0, mrp = 0, perBox = 1;

      if (numbers.isNotEmpty) qty = numbers[0];
      if (numbers.length >= 2) rate = numbers[1];
      if (numbers.length >= 3) mrp = numbers[2];

      final perBoxMatch = _perBoxPattern.firstMatch(line);
      if (perBoxMatch != null) {
        final g = perBoxMatch.group(1) ?? perBoxMatch.group(2);
        if (g != null) perBox = double.tryParse(g) ?? 1;
      }

      // Product name = the line with numbers and unit keywords stripped out.
      var name = line
          .replaceAll(_numberPattern, '')
          .replaceAll(_boxKeywords, '')
          .replaceAll(_perBoxPattern, '')
          .replaceAll(RegExp(r'[x×@₹.,\-]+'), ' ')
          .replaceAll(RegExp(r'\s+'), ' ')
          .trim();

      if (name.isEmpty) name = line; // fall back to the raw line if stripping ate everything

      // Skip lines that are purely numeric (likely a totals row) or too short to be a product.
      if (name.length < 2) continue;

      rows.add(BillRow(
        productName: name,
        quantity: qty <= 0 ? 1 : qty,
        isBox: isBox,
        piecesPerBox: perBox <= 0 ? 1 : perBox,
        purchaseRate: rate,
        mrp: mrp,
      ));
    }

    return rows;
  }
}
