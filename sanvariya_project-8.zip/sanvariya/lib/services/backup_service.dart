import 'dart:io';
import 'package:path_provider/path_provider.dart';
import 'package:share_plus/share_plus.dart';
import 'package:file_picker/file_picker.dart';
import 'package:intl/intl.dart';
import '../database/database_helper.dart';

class BackupService {
  /// Copies the live database to a timestamped file in the app's temp
  /// folder and opens the system Share sheet so the person can save it
  /// to WhatsApp, Google Drive, email, a USB drive app, etc.
  static Future<bool> createAndShareBackup() async {
    try {
      final dbPath = await DatabaseHelper.instance.getDbFilePath();
      final dbFile = File(dbPath);
      if (!await dbFile.exists()) return false;

      final tempDir = await getTemporaryDirectory();
      final stamp = DateFormat('yyyyMMdd_HHmmss').format(DateTime.now());
      final backupPath = '${tempDir.path}/sanvariya_backup_$stamp.db';
      await dbFile.copy(backupPath);

      await Share.shareXFiles(
        [XFile(backupPath)],
        text: 'Sanvariya Super Store — Backup ($stamp)',
      );
      return true;
    } catch (e) {
      return false;
    }
  }

  /// Lets the person pick a previously saved backup file and overwrites
  /// the live database with it. Closes the current db connection first
  /// and resets the cached instance so the app picks up the restored data.
  /// Returns null if the user cancelled, true on success, false on failure.
  static Future<bool?> restoreFromPickedFile() async {
    try {
      final result = await FilePicker.platform.pickFiles(
        type: FileType.any,
        withData: false,
      );
      if (result == null || result.files.single.path == null) return null;

      final pickedPath = result.files.single.path!;
      final pickedFile = File(pickedPath);
      if (!await pickedFile.exists()) return false;

      final dbPath = await DatabaseHelper.instance.getDbFilePath();
      await DatabaseHelper.instance.closeAndReset();
      await pickedFile.copy(dbPath);
      return true;
    } catch (e) {
      return false;
    }
  }
}
