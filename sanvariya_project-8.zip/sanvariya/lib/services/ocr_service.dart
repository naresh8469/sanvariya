import 'dart:io';
import 'package:image_picker/image_picker.dart';
import 'package:google_mlkit_text_recognition/google_mlkit_text_recognition.dart';

/// Reads printed text off a product package photo, fully on-device (offline).
class OcrService {
  static final ImagePicker _picker = ImagePicker();
  static final TextRecognizer _recognizer = TextRecognizer(script: TextRecognitionScript.latin);

  /// Opens the camera, takes a photo, and returns the recognized text lines.
  /// Returns null if the user cancels the camera.
  static Future<List<String>?> captureAndReadText() async {
    final XFile? photo = await _picker.pickImage(
      source: ImageSource.camera,
      imageQuality: 85,
      preferredCameraDevice: CameraDevice.rear,
    );
    if (photo == null) return null;

    final inputImage = InputImage.fromFile(File(photo.path));
    final RecognizedText result = await _recognizer.processImage(inputImage);

    // Split into clean, non-empty lines, longest first (usually the brand/product name).
    final lines = <String>[];
    for (final block in result.blocks) {
      for (final line in block.lines) {
        final text = line.text.trim();
        if (text.length >= 2) lines.add(text);
      }
    }
    lines.sort((a, b) => b.length.compareTo(a.length));
    return lines;
  }

  /// Same as [captureAndReadText] but preserves the original top-to-bottom
  /// reading order (not sorted by length) — needed for parsing a bill/invoice
  /// where each line is a separate row (product, qty, rate, etc).
  static Future<List<String>?> captureAndReadRawLines() async {
    final XFile? photo = await _picker.pickImage(
      source: ImageSource.camera,
      imageQuality: 90,
      preferredCameraDevice: CameraDevice.rear,
    );
    if (photo == null) return null;

    final inputImage = InputImage.fromFile(File(photo.path));
    final RecognizedText result = await _recognizer.processImage(inputImage);

    final lines = <String>[];
    for (final block in result.blocks) {
      for (final line in block.lines) {
        final text = line.text.trim();
        if (text.isNotEmpty) lines.add(text);
      }
    }
    return lines;
  }

  static void dispose() {
    _recognizer.close();
  }
}
