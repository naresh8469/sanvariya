import 'package:flutter/material.dart';
import '../services/backup_service.dart';
import '../theme/app_theme.dart';

class BackupScreen extends StatefulWidget {
  const BackupScreen({super.key});

  @override
  State<BackupScreen> createState() => _BackupScreenState();
}

class _BackupScreenState extends State<BackupScreen> {
  bool _backingUp = false;
  bool _restoring = false;

  Future<void> _backup() async {
    setState(() => _backingUp = true);
    final ok = await BackupService.createAndShareBackup();
    setState(() => _backingUp = false);
    if (!mounted) return;
    if (!ok) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Backup banane mein error aayi')),
      );
    }
  }

  Future<void> _restore() async {
    final confirm = await showDialog<bool>(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('Restore Karein?'),
        content: const Text(
          'Ye aapke phone ka current data (products, bills, stock — sab kuch) '
          'backup file se REPLACE kar dega. Ye undo nahi ho sakta.\n\n'
          'Kya aap sure hain?',
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Cancel')),
          TextButton(
            onPressed: () => Navigator.pop(context, true),
            child: const Text('Haan, Restore Karein', style: TextStyle(color: Colors.red)),
          ),
        ],
      ),
    );
    if (confirm != true) return;

    setState(() => _restoring = true);
    final result = await BackupService.restoreFromPickedFile();
    setState(() => _restoring = false);
    if (!mounted) return;

    if (result == null) return; // user cancelled file picker
    if (result == true) {
      showDialog(
        context: context,
        barrierDismissible: false,
        builder: (_) => AlertDialog(
          title: const Text('Restore Ho Gaya'),
          content: const Text(
            'Data restore ho gaya hai. Sahi tarah se load karne ke liye ab '
            'app ko band karke dobara kholein (poori tarah band karein, sirf minimize nahi).',
          ),
          actions: [
            TextButton(onPressed: () => Navigator.pop(context), child: const Text('OK')),
          ],
        ),
      );
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Restore fail ho gaya — file sahi backup nahi thi shayad')),
      );
    }
  }

  Widget _actionCard({
    required IconData icon,
    required Color color,
    required String title,
    required String subtitle,
    required String buttonLabel,
    required bool loading,
    required VoidCallback onPressed,
  }) {
    return Card(
      margin: const EdgeInsets.only(bottom: 16),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                CircleAvatar(backgroundColor: color.withValues(alpha: 0.12), child: Icon(icon, color: color)),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(title, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 15)),
                      Text(subtitle, style: const TextStyle(fontSize: 12, color: Colors.grey)),
                    ],
                  ),
                ),
              ],
            ),
            const SizedBox(height: 14),
            SizedBox(
              width: double.infinity,
              child: ElevatedButton(
                onPressed: loading ? null : onPressed,
                child: loading
                    ? const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white))
                    : Text(buttonLabel),
              ),
            ),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Backup / Restore')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          _actionCard(
            icon: Icons.cloud_upload_outlined,
            color: AppTheme.accentGreen,
            title: 'Backup Banayein',
            subtitle: 'Poora data (products, bills, stock, suppliers) ek file mein save karein aur WhatsApp/Drive/Email se safe jagah bhej dein.',
            buttonLabel: 'Backup Banayein aur Bhejein',
            loading: _backingUp,
            onPressed: _backup,
          ),
          _actionCard(
            icon: Icons.cloud_download_outlined,
            color: AppTheme.accentRed,
            title: 'Backup Se Restore Karein',
            subtitle: 'Pehle se saved backup file se data wapas laayein. Dhyaan rahe — current data replace ho jayega.',
            buttonLabel: 'Backup File Chunein',
            loading: _restoring,
            onPressed: _restore,
          ),
          Container(
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: AppTheme.accentOrange.withValues(alpha: 0.1),
              borderRadius: BorderRadius.circular(8),
            ),
            child: Row(
              children: [
                Icon(Icons.info_outline, color: AppTheme.accentOrange, size: 18),
                const SizedBox(width: 8),
                const Expanded(
                  child: Text(
                    'Salah: Har hafte ek baar backup zaroor banayein, taaki phone kho jaaye ya kharab ho jaaye to data surakshit rahe.',
                    style: TextStyle(fontSize: 12),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
