import 'package:flutter/material.dart';
import '../database/database_helper.dart';
import '../models/product.dart';
import '../theme/app_theme.dart';

class StockScreen extends StatefulWidget {
  const StockScreen({super.key});

  @override
  State<StockScreen> createState() => _StockScreenState();
}

class _StockScreenState extends State<StockScreen> {
  List<Product> _products = [];
  bool _loading = true;
  String _filter = 'all'; // all, low, out

  @override
  void initState() {
    super.initState();
    _loadStock();
  }

  Future<void> _loadStock() async {
    setState(() => _loading = true);
    final list = await DatabaseHelper.instance.getAllProducts();
    setState(() {
      _products = list;
      _loading = false;
    });
  }

  List<Product> get _filteredProducts {
    if (_filter == 'low') {
      return _products.where((p) => p.quantity > 0 && p.quantity <= p.minStock).toList();
    }
    if (_filter == 'out') {
      return _products.where((p) => p.quantity <= 0).toList();
    }
    return _products;
  }

  Future<void> _showAdjustDialog(Product p) async {
    final controller = TextEditingController();
    String type = 'ADD';

    await showDialog(
      context: context,
      builder: (context) => StatefulBuilder(
        builder: (context, setDialogState) => AlertDialog(
          title: Text('Adjust Stock: ${p.name}'),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Text('Current Stock: ${p.quantity} ${p.unit}'),
              const SizedBox(height: 12),
              Row(
                children: [
                  Expanded(
                    child: RadioListTile<String>(
                      value: 'ADD',
                      groupValue: type,
                      title: const Text('Add'),
                      onChanged: (v) => setDialogState(() => type = v!),
                    ),
                  ),
                  Expanded(
                    child: RadioListTile<String>(
                      value: 'REMOVE',
                      groupValue: type,
                      title: const Text('Remove'),
                      onChanged: (v) => setDialogState(() => type = v!),
                    ),
                  ),
                ],
              ),
              TextField(
                controller: controller,
                keyboardType: TextInputType.number,
                decoration: const InputDecoration(labelText: 'Quantity', border: OutlineInputBorder()),
              ),
            ],
          ),
          actions: [
            TextButton(onPressed: () => Navigator.pop(context), child: const Text('Cancel')),
            ElevatedButton(
              onPressed: () async {
                final qty = double.tryParse(controller.text) ?? 0;
                if (qty <= 0) return;
                final change = type == 'ADD' ? qty : -qty;
                await DatabaseHelper.instance.adjustStock(
                  p.id!,
                  change,
                  'MANUAL_$type',
                  note: 'Manual adjustment',
                );
                if (context.mounted) Navigator.pop(context);
                _loadStock();
              },
              child: const Text('Save'),
            ),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Stock / Inventory'),
      ),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(12),
            child: Row(
              children: [
                _filterChip('All', 'all'),
                const SizedBox(width: 8),
                _filterChip('Low Stock', 'low'),
                const SizedBox(width: 8),
                _filterChip('Out of Stock', 'out'),
              ],
            ),
          ),
          Expanded(
            child: _loading
                ? const Center(child: CircularProgressIndicator())
                : _filteredProducts.isEmpty
                    ? const Center(child: Text('Koi product nahi mila'))
                    : ListView.builder(
                        itemCount: _filteredProducts.length,
                        itemBuilder: (context, index) {
                          final p = _filteredProducts[index];
                          final outOfStock = p.quantity <= 0;
                          final lowStock = !outOfStock && p.quantity <= p.minStock;
                          return Card(
                            margin: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
                            child: ListTile(
                              title: Text(p.name),
                              subtitle: Text('Min Stock: ${p.minStock} ${p.unit}'),
                              leading: CircleAvatar(
                                backgroundColor: outOfStock
                                    ? Colors.red[100]
                                    : lowStock
                                        ? Colors.orange[100]
                                        : Colors.green[100],
                                child: Text(
                                  '${p.quantity.toStringAsFixed(0)}',
                                  style: TextStyle(
                                    fontSize: 12,
                                    color: outOfStock ? Colors.red : lowStock ? Colors.orange[800] : Colors.green[800],
                                    fontWeight: FontWeight.bold,
                                  ),
                                ),
                              ),
                              trailing: IconButton(
                                icon: const Icon(Icons.edit),
                                onPressed: () => _showAdjustDialog(p),
                              ),
                            ),
                          );
                        },
                      ),
          ),
        ],
      ),
    );
  }

  Widget _filterChip(String label, String value) {
    final selected = _filter == value;
    return ChoiceChip(
      label: Text(label),
      selected: selected,
      selectedColor: AppTheme.primaryBlue,
      labelStyle: TextStyle(color: selected ? Colors.white : Colors.black),
      onSelected: (_) => setState(() => _filter = value),
    );
  }
}
