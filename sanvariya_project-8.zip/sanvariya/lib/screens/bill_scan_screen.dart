import 'package:flutter/material.dart';
import '../database/database_helper.dart';
import '../models/supplier.dart';
import '../services/ocr_service.dart';
import '../services/bill_parser.dart';
import '../theme/app_theme.dart';

class BillScanScreen extends StatefulWidget {
  const BillScanScreen({super.key});

  @override
  State<BillScanScreen> createState() => _BillScanScreenState();
}

class _BillScanScreenState extends State<BillScanScreen> {
  List<Supplier> _suppliers = [];
  Supplier? _selectedSupplier;
  String _paymentMode = 'Cash';
  List<BillRow> _rows = [];
  bool _scanning = false;
  bool _saving = false;

  @override
  void initState() {
    super.initState();
    _loadSuppliers();
  }

  Future<void> _loadSuppliers() async {
    final list = await DatabaseHelper.instance.getAllSuppliers();
    setState(() {
      _suppliers = list;
      if (list.isNotEmpty) _selectedSupplier = list.first;
    });
  }

  Future<void> _scanBill() async {
    setState(() => _scanning = true);
    try {
      final lines = await OcrService.captureAndReadRawLines();
      setState(() => _scanning = false);
      if (lines == null) return;
      final parsed = BillLineParser.parse(lines);
      if (!mounted) return;
      if (parsed.isEmpty) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Bill mein kuch padh nahi paya — saaf photo lekar dobara try karein')),
        );
        return;
      }
      setState(() => _rows = parsed);
    } catch (e) {
      setState(() => _scanning = false);
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Scan mein error aayi, dobara try karein')),
      );
    }
  }

  void _addBlankRow() {
    setState(() => _rows.add(BillRow(productName: '')));
  }

  Future<void> _confirmAll() async {
    if (_selectedSupplier == null) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Pehle supplier select karein')));
      return;
    }
    final included = _rows.where((r) => r.include && r.productName.trim().isNotEmpty).toList();
    if (included.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Koi row select nahi hai')));
      return;
    }

    setState(() => _saving = true);
    final count = await DatabaseHelper.instance.applyScannedBill(
      supplierId: _selectedSupplier!.id!,
      supplierName: _selectedSupplier!.name,
      paymentMode: _paymentMode,
      rows: [
        for (final r in included)
          (name: r.productName.trim(), totalPieces: r.totalPieces, purchaseRate: r.purchaseRate, mrp: r.mrp),
      ],
    );
    setState(() => _saving = false);

    if (!mounted) return;
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('Stock Updated'),
        content: Text('$count products ki stock/entry update ho gayi.'),
        actions: [
          TextButton(
            onPressed: () {
              Navigator.pop(context);
              Navigator.pop(context);
            },
            child: const Text('OK'),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Bill Photo Entry')),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(12),
            child: Column(
              children: [
                DropdownButtonFormField<Supplier>(
                  value: _selectedSupplier,
                  decoration: const InputDecoration(labelText: 'Supplier'),
                  items: _suppliers.map((s) => DropdownMenuItem(value: s, child: Text(s.name))).toList(),
                  onChanged: (v) => setState(() => _selectedSupplier = v),
                ),
                if (_suppliers.isEmpty)
                  const Padding(
                    padding: EdgeInsets.only(top: 6),
                    child: Text('Koi supplier nahi hai — pehle Suppliers se add karein', style: TextStyle(color: Colors.red, fontSize: 12)),
                  ),
                const SizedBox(height: 10),
                SizedBox(
                  width: double.infinity,
                  height: 48,
                  child: ElevatedButton.icon(
                    onPressed: _scanning ? null : _scanBill,
                    icon: _scanning
                        ? const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white))
                        : const Icon(Icons.camera_alt),
                    label: Text(_rows.isEmpty ? 'Bill ki Photo Kheenchein' : 'Dobara Scan Karein'),
                  ),
                ),
              ],
            ),
          ),
          if (_rows.isNotEmpty)
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 12),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text('${_rows.length} rows mile — check karein', style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 13)),
                  TextButton.icon(onPressed: _addBlankRow, icon: const Icon(Icons.add, size: 18), label: const Text('Row jodein')),
                ],
              ),
            ),
          Expanded(
            child: _rows.isEmpty
                ? const Center(child: Text('Bill ki photo kheenchne ke baad rows yahan dikhengi', style: TextStyle(color: Colors.grey)))
                : ListView.builder(
                    padding: const EdgeInsets.all(12),
                    itemCount: _rows.length,
                    itemBuilder: (context, index) => _RowCard(
                      row: _rows[index],
                      onChanged: () => setState(() {}),
                      onDelete: () => setState(() => _rows.removeAt(index)),
                    ),
                  ),
          ),
          if (_rows.isNotEmpty)
            Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(color: AppTheme.cardBg, border: Border(top: BorderSide(color: AppTheme.cardBorder))),
              child: Row(
                children: [
                  const Text('Payment: '),
                  DropdownButton<String>(
                    value: _paymentMode,
                    items: ['Cash', 'UPI', 'Credit'].map((m) => DropdownMenuItem(value: m, child: Text(m))).toList(),
                    onChanged: (v) => setState(() => _paymentMode = v!),
                  ),
                  const Spacer(),
                  ElevatedButton.icon(
                    onPressed: _saving ? null : _confirmAll,
                    icon: _saving
                        ? const SizedBox(width: 16, height: 16, child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white))
                        : const Icon(Icons.check),
                    label: const Text('Confirm & Update Stock'),
                  ),
                ],
              ),
            ),
        ],
      ),
    );
  }
}

class _RowCard extends StatefulWidget {
  final BillRow row;
  final VoidCallback onChanged;
  final VoidCallback onDelete;
  const _RowCard({required this.row, required this.onChanged, required this.onDelete});

  @override
  State<_RowCard> createState() => _RowCardState();
}

class _RowCardState extends State<_RowCard> {
  late TextEditingController _name, _qty, _perBox, _rate, _mrp;

  @override
  void initState() {
    super.initState();
    final r = widget.row;
    _name = TextEditingController(text: r.productName);
    _qty = TextEditingController(text: r.quantity.toStringAsFixed(0));
    _perBox = TextEditingController(text: r.piecesPerBox.toStringAsFixed(0));
    _rate = TextEditingController(text: r.purchaseRate == 0 ? '' : r.purchaseRate.toStringAsFixed(2));
    _mrp = TextEditingController(text: r.mrp == 0 ? '' : r.mrp.toStringAsFixed(2));
  }

  @override
  Widget build(BuildContext context) {
    final r = widget.row;
    return Opacity(
      opacity: r.include ? 1 : 0.4,
      child: Card(
        margin: const EdgeInsets.only(bottom: 10),
        child: Padding(
          padding: const EdgeInsets.all(12),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Row(
                children: [
                  Checkbox(
                    value: r.include,
                    onChanged: (v) {
                      r.include = v ?? true;
                      widget.onChanged();
                    },
                  ),
                  Expanded(
                    child: TextField(
                      controller: _name,
                      decoration: const InputDecoration(labelText: 'Product Name', isDense: true),
                      onChanged: (v) => r.productName = v,
                    ),
                  ),
                  IconButton(icon: const Icon(Icons.delete_outline, color: Colors.red), onPressed: widget.onDelete),
                ],
              ),
              const SizedBox(height: 8),
              Row(
                children: [
                  Expanded(
                    child: TextField(
                      controller: _qty,
                      keyboardType: TextInputType.number,
                      decoration: const InputDecoration(labelText: 'Qty', isDense: true),
                      onChanged: (v) => r.quantity = double.tryParse(v) ?? 1,
                    ),
                  ),
                  const SizedBox(width: 8),
                  Expanded(
                    flex: 2,
                    child: Row(
                      children: [
                        const Text('Box?', style: TextStyle(fontSize: 12)),
                        Switch(
                          value: r.isBox,
                          onChanged: (v) {
                            r.isBox = v;
                            widget.onChanged();
                          },
                        ),
                      ],
                    ),
                  ),
                  if (r.isBox)
                    Expanded(
                      child: TextField(
                        controller: _perBox,
                        keyboardType: TextInputType.number,
                        decoration: const InputDecoration(labelText: 'Pcs/Box', isDense: true),
                        onChanged: (v) => r.piecesPerBox = double.tryParse(v) ?? 1,
                      ),
                    ),
                ],
              ),
              const SizedBox(height: 8),
              Row(
                children: [
                  Expanded(
                    child: TextField(
                      controller: _rate,
                      keyboardType: TextInputType.number,
                      decoration: const InputDecoration(labelText: 'Purchase Rate ₹', isDense: true),
                      onChanged: (v) => r.purchaseRate = double.tryParse(v) ?? 0,
                    ),
                  ),
                  const SizedBox(width: 8),
                  Expanded(
                    child: TextField(
                      controller: _mrp,
                      keyboardType: TextInputType.number,
                      decoration: const InputDecoration(labelText: 'MRP ₹', isDense: true),
                      onChanged: (v) => r.mrp = double.tryParse(v) ?? 0,
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 4),
              Text('Total pieces jud jayenge: ${r.totalPieces.toStringAsFixed(0)}', style: const TextStyle(fontSize: 11, color: Colors.grey)),
            ],
          ),
        ),
      ),
    );
  }
}
