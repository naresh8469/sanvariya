import 'package:flutter/material.dart';
import 'package:fl_chart/fl_chart.dart';
import '../database/database_helper.dart';
import '../theme/app_theme.dart';

class ReportsScreen extends StatefulWidget {
  final bool embedded;
  const ReportsScreen({super.key, this.embedded = false});

  @override
  State<ReportsScreen> createState() => _ReportsScreenState();
}

class _ReportsScreenState extends State<ReportsScreen> {
  bool _loading = true;
  double _totalSales = 0;
  double _totalPurchase = 0;
  int _totalBills = 0;
  int _totalSuppliers = 0;
  List<MapEntry<DateTime, double>> _trend = [];
  List<MapEntry<String, double>> _topProducts = [];

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() => _loading = true);
    final db = DatabaseHelper.instance;
    final sales = await db.getTotalSalesAmount();
    final purchase = await db.getTotalPurchaseAmount();
    final bills = await db.getTotalBillCount();
    final suppliers = await db.getAllSuppliers();
    final trend = await db.getSalesTrend(days: 7);
    final top = await db.getTopSellingProducts(limit: 5);

    setState(() {
      _totalSales = sales;
      _totalPurchase = purchase;
      _totalBills = bills;
      _totalSuppliers = suppliers.length;
      _trend = trend;
      _topProducts = top;
      _loading = false;
    });
  }

  Widget _statCard(String title, String value, IconData icon, Color color) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            CircleAvatar(radius: 16, backgroundColor: color.withValues(alpha: 0.12), child: Icon(icon, size: 16, color: color)),
            const SizedBox(height: 10),
            Text(title, style: const TextStyle(fontSize: 12, color: Colors.grey)),
            const SizedBox(height: 2),
            Text(value, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
          ],
        ),
      ),
    );
  }

  Widget _buildChart() {
    final maxY = _trend.isEmpty ? 100.0 : (_trend.map((e) => e.value).reduce((a, b) => a > b ? a : b) * 1.2).clamp(10, double.infinity);
    return SizedBox(
      height: 200,
      child: LineChart(
        LineChartData(
          minY: 0,
          maxY: maxY.toDouble(),
          gridData: FlGridData(show: true, drawVerticalLine: false, horizontalInterval: maxY / 4),
          borderData: FlBorderData(show: false),
          titlesData: FlTitlesData(
            leftTitles: const AxisTitles(sideTitles: SideTitles(showTitles: false)),
            rightTitles: const AxisTitles(sideTitles: SideTitles(showTitles: false)),
            topTitles: const AxisTitles(sideTitles: SideTitles(showTitles: false)),
            bottomTitles: AxisTitles(
              sideTitles: SideTitles(
                showTitles: true,
                reservedSize: 26,
                getTitlesWidget: (value, meta) {
                  final i = value.toInt();
                  if (i < 0 || i >= _trend.length) return const SizedBox.shrink();
                  final day = _trend[i].key;
                  return Padding(
                    padding: const EdgeInsets.only(top: 6),
                    child: Text('${day.day}/${day.month}', style: const TextStyle(fontSize: 10, color: Colors.grey)),
                  );
                },
              ),
            ),
          ),
          lineBarsData: [
            LineChartBarData(
              spots: [for (int i = 0; i < _trend.length; i++) FlSpot(i.toDouble(), _trend[i].value)],
              isCurved: true,
              color: AppTheme.primaryBlue,
              barWidth: 3,
              dotData: const FlDotData(show: true),
              belowBarData: BarAreaData(show: true, color: AppTheme.primaryBlue.withValues(alpha: 0.08)),
            ),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final body = _loading
        ? const Center(child: CircularProgressIndicator())
        : RefreshIndicator(
            onRefresh: _load,
            child: ListView(
              padding: const EdgeInsets.all(16),
              children: [
                GridView.count(
                  crossAxisCount: 2,
                  shrinkWrap: true,
                  physics: const NeverScrollableScrollPhysics(),
                  mainAxisSpacing: 10,
                  crossAxisSpacing: 10,
                  childAspectRatio: 1.6,
                  children: [
                    _statCard('Total Sales', '₹${_totalSales.toStringAsFixed(0)}', Icons.trending_up, AppTheme.accentGreen),
                    _statCard('Total Purchase', '₹${_totalPurchase.toStringAsFixed(0)}', Icons.shopping_bag_outlined, AppTheme.primaryBlue),
                    _statCard('Total Bills', '$_totalBills', Icons.receipt_long, AppTheme.accentOrange),
                    _statCard('Total Suppliers', '$_totalSuppliers', Icons.local_shipping_outlined, AppTheme.accentPurple),
                  ],
                ),
                const SizedBox(height: 20),
                Card(
                  child: Padding(
                    padding: const EdgeInsets.all(16),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const Text('Sales Trend (7 Din)', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 15)),
                        const SizedBox(height: 12),
                        _buildChart(),
                      ],
                    ),
                  ),
                ),
                const SizedBox(height: 20),
                Card(
                  child: Padding(
                    padding: const EdgeInsets.all(16),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const Text('Top Selling Products', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 15)),
                        const SizedBox(height: 10),
                        if (_topProducts.isEmpty)
                          const Padding(padding: EdgeInsets.symmetric(vertical: 12), child: Text('Abhi koi sale nahi hui', style: TextStyle(color: Colors.grey)))
                        else
                          ..._topProducts.map((e) => Padding(
                                padding: const EdgeInsets.symmetric(vertical: 6),
                                child: Row(
                                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                  children: [
                                    Text(e.key),
                                    Text('${e.value.toStringAsFixed(0)} sold', style: const TextStyle(color: Colors.grey)),
                                  ],
                                ),
                              )),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          );

    if (widget.embedded) {
      return Scaffold(appBar: AppBar(title: const Text('Reports')), body: body);
    }
    return Scaffold(appBar: AppBar(title: const Text('Reports')), body: body);
  }
}
