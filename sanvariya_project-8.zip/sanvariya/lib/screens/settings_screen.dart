import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../theme/app_theme.dart';
import '../theme/theme_controller.dart';

class SettingsScreen extends StatelessWidget {
  const SettingsScreen({super.key});

  Widget _themeOption(BuildContext context, ThemeController controller, AppThemeType type, String label, String subtitle, IconData icon, Color previewColor, Color previewBg) {
    final selected = controller.themeType == type;
    return Card(
      margin: const EdgeInsets.only(bottom: 12),
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(12),
        side: BorderSide(color: selected ? AppTheme.primaryBlue : AppTheme.cardBorder, width: selected ? 2 : 1),
      ),
      child: InkWell(
        borderRadius: BorderRadius.circular(12),
        onTap: () => controller.setTheme(type),
        child: Padding(
          padding: const EdgeInsets.all(14),
          child: Row(
            children: [
              Container(
                width: 56,
                height: 56,
                decoration: BoxDecoration(color: previewBg, borderRadius: BorderRadius.circular(10), border: Border.all(color: previewColor.withValues(alpha: 0.4))),
                alignment: Alignment.center,
                child: Icon(icon, color: previewColor, size: 26),
              ),
              const SizedBox(width: 14),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(label, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 15)),
                    Text(subtitle, style: const TextStyle(fontSize: 12, color: Colors.grey)),
                  ],
                ),
              ),
              if (selected) Icon(Icons.check_circle, color: AppTheme.primaryBlue),
            ],
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final controller = context.watch<ThemeController>();
    return Scaffold(
      appBar: AppBar(title: const Text('Settings')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          const Text('Theme', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
          const SizedBox(height: 12),
          _themeOption(context, controller, AppThemeType.day, 'Day', 'Halka, saaf background — dukaan mein roshni mein', Icons.wb_sunny_outlined, const Color(0xFF0D47A1), Colors.white),
          _themeOption(context, controller, AppThemeType.night, 'Night', 'Dark background — raat mein aankhon ko aaram', Icons.nightlight_round, const Color(0xFF4A90D9), const Color(0xFF1E1E1E)),
          _themeOption(context, controller, AppThemeType.hacker, 'Hacker', 'Green-on-black terminal look', Icons.terminal, const Color(0xFF00FF41), Colors.black),
        ],
      ),
    );
  }
}
