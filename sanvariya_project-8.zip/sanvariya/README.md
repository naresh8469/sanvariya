# Sanvariya Super Store — ERP

Blue-theme POS & Inventory app with bottom navigation — Login, Dashboard, Products, Billing/POS
(GST + Hold Bill), Purchase, Suppliers, Stock, Reports (sales trend chart). Built with Flutter +
SQLite (offline-first, no internet needed to run) + fl_chart.

## Ismein kya hai (current build)

**Bottom Navigation:** Dashboard · Products · Sale · Reports · More

- **Splash + Login** — username/password (default: `admin` / `admin123`, role: owner)
- **Dashboard** — welcome header, Total Sales / Purchase / Profit / Customers cards,
  8-icon Quick Actions grid, Low Stock Alert list
- **Billing/POS ("Sale")** — barcode scan/search, **camera photo scan (offline OCR)**, cart,
  Discount + GST%, Hold Bill / Held Bills recall, Cash/UPI/Credit, Checkout (auto stock deduct),
  **Print button — sends the bill to a connected Bluetooth thermal printer**
- **Printer Settings** (via More) — pick a paired Bluetooth thermal printer and save it as
  default for one-tap printing from Billing
- **Backup / Restore** (via More) — create a backup of all data and share it (WhatsApp,
  Drive, Email) to keep it safe, or restore from a previously saved backup file
- **Products** — add/edit/delete, **add new product by camera photo (offline OCR reads printed
  name)**, barcode, category, rates, MRP, stock, unit, min stock
- **Purchase** (via More) — select supplier, add products with purchase rate, saves purchase
  and auto-increases stock
- **Bill Photo Entry** (via More/Dashboard) — photo of a supplier's paper bill → offline OCR
  reads every line → editable review table (product, qty, box/piece, pcs-per-box, purchase
  rate, MRP) → Confirm updates stock for existing products or creates new ones, and saves a
  Purchase record for reports
- **Suppliers** (via More) — add/edit/delete suppliers
- **Stock** (via More) — current stock, Low Stock / Out of Stock filters, manual adjustment
- **Reports** — Total Sales/Purchase/Bills/Suppliers cards, 7-day Sales Trend line chart,
  Top Selling Products
- **Settings** (via More) — switch app theme: **Day** (light), **Night** (dark), or
  **Hacker** (green-on-black terminal look), saved automatically

Database (SQLite) tables: `users`, `products`, `sales` (with gstPercent/gstAmount/status),
`sale_items`, `stock_history`, `suppliers`, `purchases`, `purchase_items`.

Baaki modules (Barcode hardware scanner integration, Thermal Printer, Customer Management,
Sales/Purchase Return, Firebase Cloud Sync, Backup/Restore, Audit Log) is base ke upar
step-by-step add ho sakte hain.

## Apne computer/Codespaces par kaise build karein (APK banane ke liye)

1. **Flutter install karein**: https://docs.flutter.dev/get-started/install (ya GitHub
   Codespaces browser se — pehle jo instructions di thi wahi follow karein)
2. Naya Flutter project banayein:
   ```
   flutter create sanvariya_app
   cd sanvariya_app
   ```
3. Is naye folder ke `lib/` folder aur `pubspec.yaml` file ko **delete** karke, maine diya
   hua `lib/` folder aur `pubspec.yaml` copy-paste kar dein.
4. **Camera permission add karein** (naye photo-scan feature ke liye zaroori) — file
   `android/app/src/main/AndroidManifest.xml` kholkar `<manifest ...>` tag ke andar,
   `<application ...>` tag se pehle ye lines jodein:
   ```xml
   <uses-permission android:name="android.permission.CAMERA" />
   <uses-permission android:name="android.permission.BLUETOOTH" />
   <uses-permission android:name="android.permission.BLUETOOTH_ADMIN" />
   <uses-permission android:name="android.permission.BLUETOOTH_CONNECT" />
   <uses-permission android:name="android.permission.BLUETOOTH_SCAN" />
   <uses-permission android:name="android.permission.ACCESS_FINE_LOCATION" />
   ```
   (Bluetooth ke 4 permissions thermal printer connect karne ke liye zaroori hain —
   BLUETOOTH_CONNECT/SCAN naye Android (12+) ke liye, baaki purane Android ke liye.)
5. Dependencies install karein:
   ```
   flutter pub get
   ```
6. APK build karein:
   ```
   flutter build apk --release
   ```
7. APK yahaan milegi:
   ```
   build/app/outputs/flutter-apk/app-release.apk
   ```

Test karne ke liye (bina APK banaye, seedhe phone/emulator par):
```
flutter run
```

## Default Login
- Username: `admin`
- Password: `admin123`
