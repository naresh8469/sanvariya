import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import '../database/database_helper.dart';
import '../theme/app_theme.dart';
import 'products_screen.dart';
import 'billing_screen.dart';
import 'stock_screen.dart';
import 'purchase_screen.dart';
import 'bill_scan_screen.dart';
import 'suppliers_screen.dart';
import 'reports_screen.dart';

class DashboardScreen extends StatefulWidget {
  final String username;
  final String role;
  final bool embedded;

  const DashboardScreen({super.key, required this.username, required this.role, this.embedded = false});

  @override
  State<DashboardScreen> createState() => _DashboardScreenState();
}

class _DashboardScreenState extends State<DashboardScreen> {
  double _todaySales = 0;
  int _todayBillCount = 0;
  double _todayPurchase = 0;
  double _totalProfit = 0;
  int _totalCustomers = 0;
  List _lowStock = [];
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _loadStats();
  }

  Future<void> _loadStats() async {
    setState(() => _loading = true);
    final db = DatabaseHelper.instance;
    final todaySales = await db.getTodaySales();
    final todayPurchase = await db.getTodayPurchaseTotal();
    final lowStock = await db.getLowStockProducts();
    final customers = await db.getTotalCustomers();

    double salesTotal = 0;
    for (final s in todaySales) {
      salesTotal += s.totalAmount;
    }

    setState(() {
      _todaySales = salesTotal;
      _todayBillCount = todaySales.length;
      _todayPurchase = todayPurchase;
      _totalProfit = salesTotal - todayPurchase;
      _totalCustomers = customers;
      _lowStock = lowStock;
      _loading = false;
    });
  }

  Widget _statCard(String title, String value, String sub, IconData icon, Color color) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                CircleAvatar(radius: 15, backgroundColor: color.withValues(alpha: 0.15), child: Icon(icon, size: 15, color: color)),
              ],
            ),
            const SizedBox(height: 10),
            Text(title, style: const TextStyle(fontSize: 12, color: Colors.grey)),
            const SizedBox(height: 2),
            Text(value, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
            if (sub.isNotEmpty) Text(sub, style: TextStyle(fontSize: 11, color: color)),
          ],
        ),
      ),
    );
  }

  Widget _quickAction(IconData icon, String label, Color color, VoidCallback onTap) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(12),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Container(
            width: 48,
            height: 48,
            decoration: BoxDecoration(color: color.withValues(alpha: 0.12), borderRadius: BorderRadius.circular(12)),
            child: Icon(icon, color: color),
          ),
          const SizedBox(height: 6),
          Text(label, style: const TextStyle(fontSize: 11), textAlign: TextAlign.center),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final dateStr = DateFormat('d MMM yyyy, EEEE').format(DateTime.now());

    final body = _loading
        ? const Center(child: CircularProgressIndicator())
        : RefreshIndicator(
            onRefresh: _loadStats,
            child: ListView(
              padding: const EdgeInsets.only(bottom: 24),
              children: [
                Container(
                  padding: const EdgeInsets.fromLTRB(16, 8, 16, 20),
                  decoration: const BoxDecoration(
                    color: AppTheme.primaryBlue,
                    borderRadius: BorderRadius.only(bottomLeft: Radius.circular(18), bottomRight: Radius.circular(18)),
                  ),
                  child: Row(
                    children: [
                      CircleAvatar(radius: 24, backgroundColor: Colors.white, child: Icon(Icons.storefront, color: AppTheme.primaryBlue)),
                      const SizedBox(width: 12),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            const Text('Welcome Back,', style: TextStyle(color: Colors.white70, fontSize: 12)),
                            Text(widget.username, style: const TextStyle(color: Colors.white, fontSize: 18, fontWeight: FontWeight.bold)),
                            Text(widget.role[0].toUpperCase() + widget.role.substring(1), style: const TextStyle(color: Colors.white70, fontSize: 12)),
                          ],
                        ),
                      ),
                      Text(dateStr, style: const TextStyle(color: Colors.white70, fontSize: 11)),
                    ],
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.all(16),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text("Today's Overview", style: TextStyle(fontWeight: FontWeight.bold, fontSize: 15)),
                      const SizedBox(height: 10),
                      GridView.count(
                        crossAxisCount: 2,
                        shrinkWrap: true,
                        physics: const NeverScrollableScrollPhysics(),
                        mainAxisSpacing: 10,
                        crossAxisSpacing: 10,
                        childAspectRatio: 1.6,
                        children: [
                          _statCard('Total Sales', '₹${_todaySales.toStringAsFixed(0)}', '$_todayBillCount Bills', Icons.point_of_sale, AppTheme.accentGreen),
                          _statCard('Total Purchase', '₹${_todayPurchase.toStringAsFixed(0)}', 'Today', Icons.shopping_bag_outlined, AppTheme.primaryBlue),
                          _statCard('Total Profit', '₹${_totalProfit.toStringAsFixed(0)}', 'Today', Icons.trending_up, AppTheme.accentOrange),
                          _statCard('Total Customers', '$_totalCustomers', '', Icons.groups_outlined, AppTheme.accentPurple),
                        ],
                      ),
                      const SizedBox(height: 22),
                      const Text('Quick Actions', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 15)),
                      const SizedBox(height: 12),
                      GridView.count(
                        crossAxisCount: 4,
                        shrinkWrap: true,
                        physics: const NeverScrollableScrollPhysics(),
                        mainAxisSpacing: 14,
                        crossAxisSpacing: 8,
                        childAspectRatio: 0.9,
                        children: [
                          _quickAction(Icons.add_shopping_cart, 'New Sale', AppTheme.accentGreen, () async {
                            await Navigator.push(context, MaterialPageRoute(builder: (_) => const BillingScreen()));
                            _loadStats();
                          }),
                          _quickAction(Icons.inventory_2_outlined, 'Add Product', AppTheme.primaryBlue, () async {
                            await Navigator.push(context, MaterialPageRoute(builder: (_) => const ProductsScreen()));
                            _loadStats();
                          }),
                          _quickAction(Icons.local_shipping_outlined, 'Purchase', AppTheme.accentTeal, () async {
                            await Navigator.push(context, MaterialPageRoute(builder: (_) => const PurchaseScreen()));
                            _loadStats();
                          }),
                          _quickAction(Icons.groups_outlined, 'Customers', AppTheme.accentPurple, () {
                            ScaffoldMessenger.of(context).showSnackBar(
                              const SnackBar(content: Text('Customer Management jald hi aayega')),
                            );
                          }),
                          _quickAction(Icons.receipt_long, 'Bill Scan', AppTheme.accentGreen, () async {
                            await Navigator.push(context, MaterialPageRoute(builder: (_) => const BillScanScreen()));
                            _loadStats();
                          }),
                          _quickAction(Icons.local_shipping, 'Suppliers', AppTheme.accentPurple, () async {
                            await Navigator.push(context, MaterialPageRoute(builder: (_) => const SuppliersScreen()));
                            _loadStats();
                          }),
                          _quickAction(Icons.bar_chart, 'Reports', AppTheme.accentOrange, () async {
                            await Navigator.push(context, MaterialPageRoute(builder: (_) => const ReportsScreen()));
                          }),
                          _quickAction(Icons.warehouse_outlined, 'Stock', AppTheme.accentGreen, () async {
                            await Navigator.push(context, MaterialPageRoute(builder: (_) => const StockScreen()));
                            _loadStats();
                          }),
                          _quickAction(Icons.more_horiz, 'More', Colors.grey.shade700, () {}),
                        ],
                      ),
                      const SizedBox(height: 22),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          const Text('Low Stock Alert', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 15)),
                          TextButton(
                            onPressed: () async {
                              await Navigator.push(context, MaterialPageRoute(builder: (_) => const StockScreen()));
                              _loadStats();
                            },
                            child: const Text('View All'),
                          ),
                        ],
                      ),
                      if (_lowStock.isEmpty)
                        const Padding(
                          padding: EdgeInsets.symmetric(vertical: 12),
                          child: Text('Koi low stock product nahi hai', style: TextStyle(color: Colors.grey)),
                        )
                      else
                        ..._lowStock.take(4).map((p) => Card(
                              margin: const EdgeInsets.only(bottom: 8),
                              child: ListTile(
                                leading: CircleAvatar(backgroundColor: AppTheme.accentRed.withValues(alpha: 0.12), child: Icon(Icons.warning_amber, color: AppTheme.accentRed, size: 18)),
                                title: Text(p.name),
                                subtitle: Text('Stock: ${p.quantity.toStringAsFixed(0)} ${p.unit}', style: TextStyle(color: AppTheme.accentRed)),
                                trailing: const Icon(Icons.chevron_right),
                              ),
                            )),
                    ],
                  ),
                ),
              ],
            ),
          );

    if (widget.embedded) {
      return Scaffold(
        appBar: AppBar(
          title: const Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text('Sanvariya Super Store ERP', style: TextStyle(fontSize: 16)),
              Text('Complete Retail Management', style: TextStyle(fontSize: 10, fontWeight: FontWeight.normal)),
            ],
          ),
          actions: [IconButton(icon: const Icon(Icons.notifications_none), onPressed: () {})],
        ),
        body: body,
      );
    }

    return Scaffold(appBar: AppBar(title: const Text('Dashboard')), body: body);
  }
}
